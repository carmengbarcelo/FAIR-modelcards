city96/Wan2.1-I2V-14B-480P-gguf
---
base_model: Wan-AI/Wan2.1-I2V-14B-480P
library_name: gguf
quantized_by: city96
tags:
- video
- video-generation
license: apache-2.0
pipeline_tag: image-to-video
language:
- en
- zh
---
This is a direct GGUF conversion of [Wan-AI/Wan2.1-I2V-14B-480P](https://huggingface.co/Wan-AI/Wan2.1-I2V-14B-480P)

All quants are created from the FP32 base file, though I only uploaded FP16 due to it exceeding the 50GB max file limit and gguf-split loading not currently being supported in ComfyUI-GGUF.

The model files can be used with the [ComfyUI-GGUF](https://github.com/city96/ComfyUI-GGUF) custom node.

Place model files in `ComfyUI/models/unet` - see the GitHub readme for further install instructions.

The other files required can be downloaded from [this repository by Comfy-Org](https://huggingface.co/Comfy-Org/Wan_2.1_ComfyUI_repackaged/tree/main/split_files)

Please refer to [this chart](https://github.com/ggerganov/llama.cpp/blob/master/examples/perplexity/README.md#llama-3-8b-scoreboard) for a basic overview of quantization types.