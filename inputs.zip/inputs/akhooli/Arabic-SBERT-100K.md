akhooli/Arabic-SBERT-100K
---
base_model: aubmindlab/bert-base-arabertv02
datasets:
- akhooli/arabic-triplets-1m-curated-sims-len
language:
- ar
library_name: sentence-transformers
pipeline_tag: sentence-similarity
tags:
- sentence-transformers
- sentence-similarity
- feature-extraction
- generated_from_trainer
- dataset_size:75000
- loss:MatryoshkaLoss
- loss:MultipleNegativesRankingLoss
---

# Arabic-SBERT-100K

This is a [sentence-transformers](https://www.SBERT.net) model finetuned from [aubmindlab/bert-base-arabertv02](https://huggingface.co/aubmindlab/bert-base-arabertv02). 
It maps sentences & paragraphs to a 768-dimensional dense vector space and can be used for semantic textual similarity, semantic search, paraphrase mining, 
text classification, clustering, and more. 
This model is trained on 100K samples filtered from the [akhooli/arabic-triplets-1m-curated-sims-len](https://huggingface.co/datasets/akhooli/arabic-triplets-1m-curated-sims-len) dataset with 75K training and 25K validation. 
Trained for 5 epochs, with final training loss of 0.133 (using MatryoshkaLoss). 

The rest of this file is auto generated. 

========================================================================

## Model Details

### Model Description
- **Model Type:** Sentence Transformer
- **Base model:** [aubmindlab/bert-base-arabertv02](https://huggingface.co/aubmindlab/bert-base-arabertv02) <!-- at revision 016fb9d6768f522a59c6e0d2d5d5d43a4e1bff60 -->
- **Maximum Sequence Length:** 512 tokens
- **Output Dimensionality:** 768 tokens
- **Similarity Function:** Cosine Similarity
<!-- - **Training Dataset:** Unknown -->
<!-- - **Language:** Unknown -->
<!-- - **License:** Unknown -->

### Model Sources

- **Documentation:** [Sentence Transformers Documentation](https://sbert.net)
- **Repository:** [Sentence Transformers on GitHub](https://github.com/UKPLab/sentence-transformers)
- **Hugging Face:** [Sentence Transformers on Hugging Face](https://huggingface.co/models?library=sentence-transformers)

### Full Model Architecture

```
SentenceTransformer(
  (0): Transformer({'max_seq_length': 512, 'do_lower_case': False}) with Transformer model: BertModel 
  (1): Pooling({'word_embedding_dimension': 768, 'pooling_mode_cls_token': False, 'pooling_mode_mean_tokens': True, 'pooling_mode_max_tokens': False, 'pooling_mode_mean_sqrt_len_tokens': False, 'pooling_mode_weightedmean_tokens': False, 'pooling_mode_lasttoken': False, 'include_prompt': True})
)
```

## Usage

### Direct Usage (Sentence Transformers)

First install the Sentence Transformers library:

```bash
pip install -U sentence-transformers
```

Then you can load this model and run inference.
```python
from sentence_transformers import SentenceTransformer

# Download from the 🤗 Hub
model = SentenceTransformer("sentence_transformers_model_id")
# Run inference
sentences = [
    'ما هو نوع الدهون الموجودة في الأفوكادو',
    'حوالي 15 في المائة من الدهون في الأفوكادو مشبعة ، مع كل كوب واحد من الأفوكادو المفروم يحتوي على 3.2 جرام من الدهون المشبعة ، وهو ما يمثل 16 في المائة من DV البالغ 20 جرامًا. تحتوي الأفوكادو في الغالب على دهون أحادية غير مشبعة ، مع 67 في المائة من إجمالي الدهون ، أو 14.7 جرامًا لكل كوب مفروم ، ويتكون من هذا النوع من الدهون.',
    'يمكن أن يؤدي ارتفاع مستوى الدهون الثلاثية ، وهي نوع من الدهون (الدهون) في الدم ، إلى زيادة خطر الإصابة بأمراض القلب ، ويمكن أن يؤدي توفير مستوى مرتفع من الدهون الثلاثية ، وهي نوع من الدهون (الدهون) في الدم ، إلى زيادة خطر الإصابة بأمراض القلب. مرض.',
]
embeddings = model.encode(sentences)
print(embeddings.shape)
# [3, 768]

# Get the similarity scores for the embeddings
similarities = model.similarity(embeddings, embeddings)
print(similarities.shape)
# [3, 3]
```

<!--
### Direct Usage (Transformers)

<details><summary>Click to see the direct usage in Transformers</summary>

</details>
-->

<!--
### Downstream Usage (Sentence Transformers)

You can finetune this model on your own dataset.

<details><summary>Click to expand</summary>

</details>
-->

<!--
### Out-of-Scope Use

*List how the model may foreseeably be misused and address what users ought not to do with the model.*
-->

<!--
## Bias, Risks and Limitations

*What are the known or foreseeable issues stemming from this model? You could also flag here known failure cases or weaknesses of the model.*
-->

<!--
### Recommendations

*What are recommendations with respect to the foreseeable issues? For example, filtering explicit content.*
-->

## Training Details

### Training Dataset

#### Unnamed Dataset


* Size: 75,000 training samples
* Columns: <code>anchor</code>, <code>positive</code>, and <code>negative</code>
* Approximate statistics based on the first 1000 samples:
  |         | anchor                                                                            | positive                                                                           | negative                                                                           |
  |:--------|:----------------------------------------------------------------------------------|:-----------------------------------------------------------------------------------|:-----------------------------------------------------------------------------------|
  | type    | string                                                                            | string                                                                             | string                                                                             |
  | details | <ul><li>min: 4 tokens</li><li>mean: 12.88 tokens</li><li>max: 58 tokens</li></ul> | <ul><li>min: 4 tokens</li><li>mean: 13.74 tokens</li><li>max: 126 tokens</li></ul> | <ul><li>min: 4 tokens</li><li>mean: 13.38 tokens</li><li>max: 146 tokens</li></ul> |
* Samples:
  | anchor                                                                                    | positive                                                      | negative                                          |
  |:------------------------------------------------------------------------------------------|:--------------------------------------------------------------|:--------------------------------------------------|
  | <code>هل تشاجر (سي إس لويس) و (جي آر آر تولكين) ؟ إن كان الأمر كذلك، فما هو السبب؟</code> | <code>هل صحيح أن (سي إس لويس) و (تولكين) تشاجرا؟</code>       | <code>ما هي أفضل الكتب للدراسة في الجامعة؟</code> |
  | <code>ما هي اعراض فقر الدم؟</code>                                                        | <code>ما هي اعراض الانيميا؟</code>                            | <code>كيف احضر  كيكة العسل؟</code>                |
  | <code>من ستصوت له، دونالد ترامب أم هيلاري كلينتون؟</code>                                 | <code>هل تؤيدون دونالد ترامب أم هيلاري كلينتون؟ لماذا؟</code> | <code>كيف أتغلب على إدمان المواد الإباحية؟</code> |
* Loss: [<code>MatryoshkaLoss</code>](https://sbert.net/docs/package_reference/sentence_transformer/losses.html#matryoshkaloss) with these parameters:
  ```json
  {
      "loss": "MultipleNegativesRankingLoss",
      "matryoshka_dims": [
          768,
          512,
          256,
          128,
          64
      ],
      "matryoshka_weights": [
          1,
          1,
          1,
          1,
          1
      ],
      "n_dims_per_step": -1
  }
  ```

### Evaluation Dataset

#### Unnamed Dataset


* Size: 25,000 evaluation samples
* Columns: <code>anchor</code>, <code>positive</code>, and <code>negative</code>
* Approximate statistics based on the first 1000 samples:
  |         | anchor                                                                           | positive                                                                           | negative                                                                           |
  |:--------|:---------------------------------------------------------------------------------|:-----------------------------------------------------------------------------------|:-----------------------------------------------------------------------------------|
  | type    | string                                                                           | string                                                                             | string                                                                             |
  | details | <ul><li>min: 4 tokens</li><li>mean: 12.6 tokens</li><li>max: 70 tokens</li></ul> | <ul><li>min: 4 tokens</li><li>mean: 14.82 tokens</li><li>max: 239 tokens</li></ul> | <ul><li>min: 4 tokens</li><li>mean: 13.78 tokens</li><li>max: 128 tokens</li></ul> |
* Samples:
  | anchor                                                     | positive                                                     | negative                                    |
  |:-----------------------------------------------------------|:-------------------------------------------------------------|:--------------------------------------------|
  | <code>نعم , نعم , أو رأيت " تشيما بارا ديسو "</code>       | <code>نعم، أو "تشيما بارا ديسو" كانت تلك التي شاهدتها</code> | <code>أنا لم أرى "تشيما بارا ديسو".</code>  |
  | <code>رجل وامرأة يجلسان على الشاطئ بينما تغرب الشمس</code> | <code>هناك رجل وامرأة يجلسان على الشاطئ</code>               | <code>إنهم يشاهدون شروق الشمس</code>        |
  | <code>كيف أسيطر على غضبي؟</code>                           | <code>ما هي أفضل طريقة للسيطرة على الغضب؟</code>             | <code>كيف أعرف إن كانت زوجتي تخونني؟</code> |
* Loss: [<code>MatryoshkaLoss</code>](https://sbert.net/docs/package_reference/sentence_transformer/losses.html#matryoshkaloss) with these parameters:
  ```json
  {
      "loss": "MultipleNegativesRankingLoss",
      "matryoshka_dims": [
          768,
          512,
          256,
          128,
          64
      ],
      "matryoshka_weights": [
          1,
          1,
          1,
          1,
          1
      ],
      "n_dims_per_step": -1
  }
  ```

### Training Hyperparameters
#### Non-Default Hyperparameters

- `eval_strategy`: steps
- `per_device_train_batch_size`: 16
- `per_device_eval_batch_size`: 16
- `learning_rate`: 2e-05
- `num_train_epochs`: 5
- `warmup_ratio`: 0.1
- `fp16`: True
- `batch_sampler`: no_duplicates

#### All Hyperparameters
<details><summary>Click to expand</summary>

- `overwrite_output_dir`: False
- `do_predict`: False
- `eval_strategy`: steps
- `prediction_loss_only`: True
- `per_device_train_batch_size`: 16
- `per_device_eval_batch_size`: 16
- `per_gpu_train_batch_size`: None
- `per_gpu_eval_batch_size`: None
- `gradient_accumulation_steps`: 1
- `eval_accumulation_steps`: None
- `learning_rate`: 2e-05
- `weight_decay`: 0.0
- `adam_beta1`: 0.9
- `adam_beta2`: 0.999
- `adam_epsilon`: 1e-08
- `max_grad_norm`: 1.0
- `num_train_epochs`: 5
- `max_steps`: -1
- `lr_scheduler_type`: linear
- `lr_scheduler_kwargs`: {}
- `warmup_ratio`: 0.1
- `warmup_steps`: 0
- `log_level`: passive
- `log_level_replica`: warning
- `log_on_each_node`: True
- `logging_nan_inf_filter`: True
- `save_safetensors`: True
- `save_on_each_node`: False
- `save_only_model`: False
- `restore_callback_states_from_checkpoint`: False
- `no_cuda`: False
- `use_cpu`: False
- `use_mps_device`: False
- `seed`: 42
- `data_seed`: None
- `jit_mode_eval`: False
- `use_ipex`: False
- `bf16`: False
- `fp16`: True
- `fp16_opt_level`: O1
- `half_precision_backend`: auto
- `bf16_full_eval`: False
- `fp16_full_eval`: False
- `tf32`: None
- `local_rank`: 0
- `ddp_backend`: None
- `tpu_num_cores`: None
- `tpu_metrics_debug`: False
- `debug`: []
- `dataloader_drop_last`: False
- `dataloader_num_workers`: 0
- `dataloader_prefetch_factor`: None
- `past_index`: -1
- `disable_tqdm`: False
- `remove_unused_columns`: True
- `label_names`: None
- `load_best_model_at_end`: False
- `ignore_data_skip`: False
- `fsdp`: []
- `fsdp_min_num_params`: 0
- `fsdp_config`: {'min_num_params': 0, 'xla': False, 'xla_fsdp_v2': False, 'xla_fsdp_grad_ckpt': False}
- `fsdp_transformer_layer_cls_to_wrap`: None
- `accelerator_config`: {'split_batches': False, 'dispatch_batches': None, 'even_batches': True, 'use_seedable_sampler': True, 'non_blocking': False, 'gradient_accumulation_kwargs': None}
- `deepspeed`: None
- `label_smoothing_factor`: 0.0
- `optim`: adamw_torch
- `optim_args`: None
- `adafactor`: False
- `group_by_length`: False
- `length_column_name`: length
- `ddp_find_unused_parameters`: None
- `ddp_bucket_cap_mb`: None
- `ddp_broadcast_buffers`: False
- `dataloader_pin_memory`: True
- `dataloader_persistent_workers`: False
- `skip_memory_metrics`: True
- `use_legacy_prediction_loop`: False
- `push_to_hub`: False
- `resume_from_checkpoint`: None
- `hub_model_id`: None
- `hub_strategy`: every_save
- `hub_private_repo`: False
- `hub_always_push`: False
- `gradient_checkpointing`: False
- `gradient_checkpointing_kwargs`: None
- `include_inputs_for_metrics`: False
- `eval_do_concat_batches`: True
- `fp16_backend`: auto
- `push_to_hub_model_id`: None
- `push_to_hub_organization`: None
- `mp_parameters`: 
- `auto_find_batch_size`: False
- `full_determinism`: False
- `torchdynamo`: None
- `ray_scope`: last
- `ddp_timeout`: 1800
- `torch_compile`: False
- `torch_compile_backend`: None
- `torch_compile_mode`: None
- `dispatch_batches`: None
- `split_batches`: None
- `include_tokens_per_second`: False
- `include_num_input_tokens_seen`: False
- `neftune_noise_alpha`: None
- `optim_target_modules`: None
- `batch_eval_metrics`: False
- `eval_on_start`: False
- `batch_sampler`: no_duplicates
- `multi_dataset_batch_sampler`: proportional

</details>

### Training Logs
| Epoch  | Step  | Training Loss | loss   |
|:------:|:-----:|:-------------:|:------:|
| 0.2133 | 500   | 1.4163        | 0.3134 |
| 0.4266 | 1000  | 0.3306        | 0.1912 |
| 0.6399 | 1500  | 0.2263        | 0.1527 |
| 0.8532 | 2000  | 0.1818        | 0.1297 |
| 1.0666 | 2500  | 0.1658        | 0.1167 |
| 1.2799 | 3000  | 0.1139        | 0.1040 |
| 1.4932 | 3500  | 0.0808        | 0.1018 |
| 1.7065 | 4000  | 0.0692        | 0.0959 |
| 1.9198 | 4500  | 0.058         | 0.0958 |
| 2.1331 | 5000  | 0.0653        | 0.0882 |
| 2.3464 | 5500  | 0.0503        | 0.0912 |
| 2.5597 | 6000  | 0.0338        | 0.0970 |
| 2.7730 | 6500  | 0.0363        | 0.0906 |
| 2.9863 | 7000  | 0.0375        | 0.0856 |
| 3.1997 | 7500  | 0.0401        | 0.0879 |
| 3.4130 | 8000  | 0.031         | 0.0848 |
| 3.6263 | 8500  | 0.0255        | 0.0938 |
| 3.8396 | 9000  | 0.0239        | 0.0858 |
| 4.0529 | 9500  | 0.0305        | 0.0840 |
| 4.2662 | 10000 | 0.0281        | 0.0833 |
| 4.4795 | 10500 | 0.0174        | 0.0840 |
| 4.6928 | 11000 | 0.0216        | 0.0882 |
| 4.9061 | 11500 | 0.022         | 0.0866 |


### Framework Versions
- Python: 3.10.13
- Sentence Transformers: 3.0.1
- Transformers: 4.42.3
- PyTorch: 2.1.2
- Accelerate: 0.32.1
- Datasets: 2.20.0
- Tokenizers: 0.19.1

## Citation

### BibTeX

#### Sentence Transformers
```bibtex
@inproceedings{reimers-2019-sentence-bert,
    title = "Sentence-BERT: Sentence Embeddings using Siamese BERT-Networks",
    author = "Reimers, Nils and Gurevych, Iryna",
    booktitle = "Proceedings of the 2019 Conference on Empirical Methods in Natural Language Processing",
    month = "11",
    year = "2019",
    publisher = "Association for Computational Linguistics",
    url = "https://arxiv.org/abs/1908.10084",
}
```

#### MatryoshkaLoss
```bibtex
@misc{kusupati2024matryoshka,
    title={Matryoshka Representation Learning}, 
    author={Aditya Kusupati and Gantavya Bhatt and Aniket Rege and Matthew Wallingford and Aditya Sinha and Vivek Ramanujan and William Howard-Snyder and Kaifeng Chen and Sham Kakade and Prateek Jain and Ali Farhadi},
    year={2024},
    eprint={2205.13147},
    archivePrefix={arXiv},
    primaryClass={cs.LG}
}
```

#### MultipleNegativesRankingLoss
```bibtex
@misc{henderson2017efficient,
    title={Efficient Natural Language Response Suggestion for Smart Reply}, 
    author={Matthew Henderson and Rami Al-Rfou and Brian Strope and Yun-hsuan Sung and Laszlo Lukacs and Ruiqi Guo and Sanjiv Kumar and Balint Miklos and Ray Kurzweil},
    year={2017},
    eprint={1705.00652},
    archivePrefix={arXiv},
    primaryClass={cs.CL}
}
```

<!--
## Glossary

*Clearly define terms in order to be accessible across audiences.*
-->

<!--
## Model Card Authors

*Lists the people who create the model card, providing recognition and accountability for the detailed work that goes into its construction.*
-->

<!--
## Model Card Contact

*Provides a way for people who have updates to the Model Card, suggestions, or questions, to contact the Model Card authors.*
-->