Arunavaonly/Bangla-twoclass-Sentiment-Analyzer
---
license: mit
base_model: xlm-roberta-base
tags:
- generated_from_trainer
metrics:
- f1
model-index:
- name: Bangla-Twoclass-Sentiment-Analyzer
  results: []
---

<!-- This model card has been generated automatically according to the information the Trainer had access to. You
should probably proofread and complete it, then remove this comment. -->

# Bangla-Twoclass-Sentiment-Analyzer

This model is a fine-tuned version of [xlm-roberta-base](https://huggingface.co/xlm-roberta-base) on the None dataset.
It achieves the following results on the evaluation set:
- Loss: 2.7755
- F1: 0.6113

## Model description

More information needed

## Intended uses & limitations

More information needed

## Training and evaluation data

More information needed

## Training procedure

### Training hyperparameters

The following hyperparameters were used during training:
- learning_rate: 3e-05
- train_batch_size: 16
- eval_batch_size: 16
- seed: 42
- optimizer: Adam with betas=(0.9,0.999) and epsilon=1e-08
- lr_scheduler_type: linear
- training_steps: 1800
- mixed_precision_training: Native AMP

### Training results

| Training Loss | Epoch | Step | Validation Loss | F1     |
|:-------------:|:-----:|:----:|:---------------:|:------:|
| No log        | 2.53  | 200  | 0.9869          | 0.4635 |
| No log        | 5.06  | 400  | 0.8978          | 0.5858 |
| 0.8692        | 7.59  | 600  | 1.1978          | 0.6149 |
| 0.8692        | 10.13 | 800  | 1.5145          | 0.6112 |
| 0.3138        | 12.66 | 1000 | 2.0353          | 0.6041 |
| 0.3138        | 15.19 | 1200 | 2.4316          | 0.6203 |
| 0.3138        | 17.72 | 1400 | 2.6025          | 0.6002 |
| 0.0769        | 20.25 | 1600 | 2.6247          | 0.6082 |
| 0.0769        | 22.78 | 1800 | 2.7755          | 0.6113 |


### Framework versions

- Transformers 4.37.2
- Pytorch 2.1.0+cu121
- Datasets 2.17.1
- Tokenizers 0.15.2