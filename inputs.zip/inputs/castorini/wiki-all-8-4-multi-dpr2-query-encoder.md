castorini/wiki-all-8-4-multi-dpr2-query-encoder
---
{}
---
Dense passage retriever (DPR) is a dense retrieval method described in the following paper:

> Vladimir Karpukhin, Barlas Oğuz, Sewon Min, Patrick Lewis, Ledell Wu, Sergey Edunov, Danqi Chen, Wen-tau Yih. [Dense Passage Retrieval for Open-Domain Question Answering](https://www.aclweb.org/anthology/2020.emnlp-main.550/). _Proceedings of the 2020 Conference on Empirical Methods in Natural Language Processing (EMNLP)_, pages 6769-6781, 2020.

We have trained our own DPR models with our Wikipedia corpus variants using the [Tevatron](https://github.com/texttron/tevatron) library.

Our own efforts are described in the paper entitled: 
> Pre-Processing Matters! Improved Wikipedia Corpora for Open-Domain Question Answering.

This is the query encoder portion of a 2nd iteration DPR model for the wiki-all-8-4 corpus variant trained on the amalgamation of the NQ, TriviaQA, WQ, and CuratedTREC datasets.