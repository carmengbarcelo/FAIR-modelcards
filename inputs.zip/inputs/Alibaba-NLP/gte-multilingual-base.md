Alibaba-NLP/gte-multilingual-base
---
tags:
- mteb
- sentence-transformers
- transformers
- multilingual
- sentence-similarity
- text-embeddings-inference
license: apache-2.0
language:
- af
- ar
- az
- be
- bg
- bn
- ca
- ceb
- cs
- cy
- da
- de
- el
- en
- es
- et
- eu
- fa
- fi
- fr
- gl
- gu
- he
- hi
- hr
- ht
- hu
- hy
- id
- is
- it
- ja
- jv
- ka
- kk
- km
- kn
- ko
- ky
- lo
- lt
- lv
- mk
- ml
- mn
- mr
- ms
- my
- ne
- nl
- 'no'
- pa
- pl
- pt
- qu
- ro
- ru
- si
- sk
- sl
- so
- sq
- sr
- sv
- sw
- ta
- te
- th
- tl
- tr
- uk
- ur
- vi
- yo
- zh
model-index:
- name: gte-multilingual-base (dense)
  results:
  - task:
      type: Clustering
    dataset:
      name: MTEB 8TagsClustering
      type: PL-MTEB/8tags-clustering
      config: default
      split: test
      revision: None
    metrics:
    - type: v_measure
      value: 33.66681726329994
  - task:
      type: STS
    dataset:
      name: MTEB AFQMC
      type: C-MTEB/AFQMC
      config: default
      split: validation
      revision: b44c3b011063adb25877c13823db83bb193913c4
    metrics:
    - type: cos_sim_spearman
      value: 43.54760696384009
  - task:
      type: STS
    dataset:
      name: MTEB ATEC
      type: C-MTEB/ATEC
      config: default
      split: test
      revision: 0f319b1142f28d00e055a6770f3f726ae9b7d865
    metrics:
    - type: cos_sim_spearman
      value: 48.91186363417501
  - task:
      type: Classification
    dataset:
      name: MTEB AllegroReviews
      type: PL-MTEB/allegro-reviews
      config: default
      split: test
      revision: None
    metrics:
    - type: accuracy
      value: 41.689860834990064
  - task:
      type: Clustering
    dataset:
      name: MTEB AlloProfClusteringP2P
      type: lyon-nlp/alloprof
      config: default
      split: test
      revision: 392ba3f5bcc8c51f578786c1fc3dae648662cb9b
    metrics:
    - type: v_measure
      value: 54.20241337977897
    - type: v_measure
      value: 44.34083695608643
  - task:
      type: Reranking
    dataset:
      name: MTEB AlloprofReranking
      type: lyon-nlp/mteb-fr-reranking-alloprof-s2p
      config: default
      split: test
      revision: 666fdacebe0291776e86f29345663dfaf80a0db9
    metrics:
    - type: map
      value: 64.91495250072002
  - task:
      type: Retrieval
    dataset:
      name: MTEB AlloprofRetrieval
      type: lyon-nlp/alloprof
      config: default
      split: test
      revision: 392ba3f5bcc8c51f578786c1fc3dae648662cb9b
    metrics:
    - type: ndcg_at_10
      value: 53.638
  - task:
      type: Classification
    dataset:
      name: MTEB AmazonCounterfactualClassification (en)
      type: mteb/amazon_counterfactual
      config: en
      split: test
      revision: e8379541af4e31359cca9fbcf4b00f2671dba205
    metrics:
    - type: accuracy
      value: 75.95522388059702
  - task:
      type: Classification
    dataset:
      name: MTEB AmazonPolarityClassification
      type: mteb/amazon_polarity
      config: default
      split: test
      revision: e2d317d38cd51312af73b3d32a06d1a08b442046
    metrics:
    - type: accuracy
      value: 80.717625
  - task:
      type: Classification
    dataset:
      name: MTEB AmazonReviewsClassification (en)
      type: mteb/amazon_reviews_multi
      config: en
      split: test
      revision: 1399c76144fd37290681b995c656ef9b2e06e26d
    metrics:
    - type: accuracy
      value: 43.64199999999999
  - task:
      type: Classification
    dataset:
      name: MTEB AmazonReviewsClassification (de)
      type: mteb/amazon_reviews_multi
      config: de
      split: test
      revision: 1399c76144fd37290681b995c656ef9b2e06e26d
    metrics:
    - type: accuracy
      value: 40.108
  - task:
      type: Classification
    dataset:
      name: MTEB AmazonReviewsClassification (es)
      type: mteb/amazon_reviews_multi
      config: es
      split: test
      revision: 1399c76144fd37290681b995c656ef9b2e06e26d
    metrics:
    - type: accuracy
      value: 40.169999999999995
  - task:
      type: Classification
    dataset:
      name: MTEB AmazonReviewsClassification (fr)
      type: mteb/amazon_reviews_multi
      config: fr
      split: test
      revision: 1399c76144fd37290681b995c656ef9b2e06e26d
    metrics:
    - type: accuracy
      value: 39.56799999999999
  - task:
      type: Classification
    dataset:
      name: MTEB AmazonReviewsClassification (ja)
      type: mteb/amazon_reviews_multi
      config: ja
      split: test
      revision: 1399c76144fd37290681b995c656ef9b2e06e26d
    metrics:
    - type: accuracy
      value: 35.75000000000001
  - task:
      type: Classification
    dataset:
      name: MTEB AmazonReviewsClassification (zh)
      type: mteb/amazon_reviews_multi
      config: zh
      split: test
      revision: 1399c76144fd37290681b995c656ef9b2e06e26d
    metrics:
    - type: accuracy
      value: 33.342000000000006
  - task:
      type: Retrieval
    dataset:
      name: MTEB ArguAna
      type: mteb/arguana
      config: default
      split: test
      revision: c22ab2a51041ffd869aaddef7af8d8215647e41a
    metrics:
    - type: ndcg_at_10
      value: 58.231
  - task:
      type: Retrieval
    dataset:
      name: MTEB ArguAna-PL
      type: clarin-knext/arguana-pl
      config: default
      split: test
      revision: 63fc86750af76253e8c760fc9e534bbf24d260a2
    metrics:
    - type: ndcg_at_10
      value: 53.166000000000004
  - task:
      type: Clustering
    dataset:
      name: MTEB ArxivClusteringP2P
      type: mteb/arxiv-clustering-p2p
      config: default
      split: test
      revision: a122ad7f3f0291bf49cc6f4d32aa80929df69d5d
    metrics:
    - type: v_measure
      value: 46.01900557959478
  - task:
      type: Clustering
    dataset:
      name: MTEB ArxivClusteringS2S
      type: mteb/arxiv-clustering-s2s
      config: default
      split: test
      revision: f910caf1a6075f7329cdf8c1a6135696f37dbd53
    metrics:
    - type: v_measure
      value: 41.06626465345723
  - task:
      type: Reranking
    dataset:
      name: MTEB AskUbuntuDupQuestions
      type: mteb/askubuntudupquestions-reranking
      config: default
      split: test
      revision: 2000358ca161889fa9c082cb41daa8dcfb161a54
    metrics:
    - type: map
      value: 61.87514497610431
  - task:
      type: STS
    dataset:
      name: MTEB BIOSSES
      type: mteb/biosses-sts
      config: default
      split: test
      revision: d3fb88f8f02e40887cd149695127462bbcf29b4a
    metrics:
    - type: cos_sim_spearman
      value: 81.21450112991194
  - task:
      type: STS
    dataset:
      name: MTEB BQ
      type: C-MTEB/BQ
      config: default
      split: test
      revision: e3dda5e115e487b39ec7e618c0c6a29137052a55
    metrics:
    - type: cos_sim_spearman
      value: 51.71589543397271
  - task:
      type: Retrieval
    dataset:
      name: MTEB BSARDRetrieval
      type: maastrichtlawtech/bsard
      config: default
      split: test
      revision: 5effa1b9b5fa3b0f9e12523e6e43e5f86a6e6d59
    metrics:
    - type: ndcg_at_10
      value: 26.115
  - task:
      type: BitextMining
    dataset:
      name: MTEB BUCC (de-en)
      type: mteb/bucc-bitext-mining
      config: de-en
      split: test
      revision: d51519689f32196a32af33b075a01d0e7c51e252
    metrics:
    - type: f1
      value: 98.6169102296451
  - task:
      type: BitextMining
    dataset:
      name: MTEB BUCC (fr-en)
      type: mteb/bucc-bitext-mining
      config: fr-en
      split: test
      revision: d51519689f32196a32af33b075a01d0e7c51e252
    metrics:
    - type: f1
      value: 97.89603052314916
  - task:
      type: BitextMining
    dataset:
      name: MTEB BUCC (ru-en)
      type: mteb/bucc-bitext-mining
      config: ru-en
      split: test
      revision: d51519689f32196a32af33b075a01d0e7c51e252
    metrics:
    - type: f1
      value: 97.12388869645537
  - task:
      type: BitextMining
    dataset:
      name: MTEB BUCC (zh-en)
      type: mteb/bucc-bitext-mining
      config: zh-en
      split: test
      revision: d51519689f32196a32af33b075a01d0e7c51e252
    metrics:
    - type: f1
      value: 98.15692469720906
  - task:
      type: Classification
    dataset:
      name: MTEB Banking77Classification
      type: mteb/banking77
      config: default
      split: test
      revision: 0fd18e25b25c072e09e0d92ab615fda904d66300
    metrics:
    - type: accuracy
      value: 85.36038961038962
  - task:
      type: Clustering
    dataset:
      name: MTEB BiorxivClusteringP2P
      type: mteb/biorxiv-clustering-p2p
      config: default
      split: test
      revision: 65b79d1d13f80053f67aca9498d9402c2d9f1f40
    metrics:
    - type: v_measure
      value: 37.5903826674123
  - task:
      type: Clustering
    dataset:
      name: MTEB BiorxivClusteringS2S
      type: mteb/biorxiv-clustering-s2s
      config: default
      split: test
      revision: 258694dd0231531bc1fd9de6ceb52a0853c6d908
    metrics:
    - type: v_measure
      value: 34.21474277151329
  - task:
      type: Classification
    dataset:
      name: MTEB CBD
      type: PL-MTEB/cbd
      config: default
      split: test
      revision: None
    metrics:
    - type: accuracy
      value: 62.519999999999996
  - task:
      type: PairClassification
    dataset:
      name: MTEB CDSC-E
      type: PL-MTEB/cdsce-pairclassification
      config: default
      split: test
      revision: None
    metrics:
    - type: cos_sim_ap
      value: 74.90132799162956
  - task:
      type: STS
    dataset:
      name: MTEB CDSC-R
      type: PL-MTEB/cdscr-sts
      config: default
      split: test
      revision: None
    metrics:
    - type: cos_sim_spearman
      value: 90.30727955142524
  - task:
      type: Clustering
    dataset:
      name: MTEB CLSClusteringP2P
      type: C-MTEB/CLSClusteringP2P
      config: default
      split: test
      revision: 4b6227591c6c1a73bc76b1055f3b7f3588e72476
    metrics:
    - type: v_measure
      value: 37.94850105022274
  - task:
      type: Clustering
    dataset:
      name: MTEB CLSClusteringS2S
      type: C-MTEB/CLSClusteringS2S
      config: default
      split: test
      revision: e458b3f5414b62b7f9f83499ac1f5497ae2e869f
    metrics:
    - type: v_measure
      value: 38.11958675421534
  - task:
      type: Reranking
    dataset:
      name: MTEB CMedQAv1
      type: C-MTEB/CMedQAv1-reranking
      config: default
      split: test
      revision: 8d7f1e942507dac42dc58017c1a001c3717da7df
    metrics:
    - type: map
      value: 86.10950950485399
  - task:
      type: Reranking
    dataset:
      name: MTEB CMedQAv2
      type: C-MTEB/CMedQAv2-reranking
      config: default
      split: test
      revision: 23d186750531a14a0357ca22cd92d712fd512ea0
    metrics:
    - type: map
      value: 87.28038294231966
  - task:
      type: Retrieval
    dataset:
      name: MTEB CQADupstackAndroidRetrieval
      type: mteb/cqadupstack-android
      config: default
      split: test
      revision: f46a197baaae43b4f621051089b82a364682dfeb
    metrics:
    - type: ndcg_at_10
      value: 47.099000000000004
  - task:
      type: Retrieval
    dataset:
      name: MTEB CQADupstackEnglishRetrieval
      type: mteb/cqadupstack-english
      config: default
      split: test
      revision: ad9991cb51e31e31e430383c75ffb2885547b5f0
    metrics:
    - type: ndcg_at_10
      value: 45.973000000000006
  - task:
      type: Retrieval
    dataset:
      name: MTEB CQADupstackGamingRetrieval
      type: mteb/cqadupstack-gaming
      config: default
      split: test
      revision: 4885aa143210c98657558c04aaf3dc47cfb54340
    metrics:
    - type: ndcg_at_10
      value: 55.606
  - task:
      type: Retrieval
    dataset:
      name: MTEB CQADupstackGisRetrieval
      type: mteb/cqadupstack-gis
      config: default
      split: test
      revision: 5003b3064772da1887988e05400cf3806fe491f2
    metrics:
    - type: ndcg_at_10
      value: 36.638
  - task:
      type: Retrieval
    dataset:
      name: MTEB CQADupstackMathematicaRetrieval
      type: mteb/cqadupstack-mathematica
      config: default
      split: test
      revision: 90fceea13679c63fe563ded68f3b6f06e50061de
    metrics:
    - type: ndcg_at_10
      value: 30.711
  - task:
      type: Retrieval
    dataset:
      name: MTEB CQADupstackPhysicsRetrieval
      type: mteb/cqadupstack-physics
      config: default
      split: test
      revision: 79531abbd1fb92d06c6d6315a0cbbbf5bb247ea4
    metrics:
    - type: ndcg_at_10
      value: 44.523
  - task:
      type: Retrieval
    dataset:
      name: MTEB CQADupstackProgrammersRetrieval
      type: mteb/cqadupstack-programmers
      config: default
      split: test
      revision: 6184bc1440d2dbc7612be22b50686b8826d22b32
    metrics:
    - type: ndcg_at_10
      value: 37.940000000000005
  - task:
      type: Retrieval
    dataset:
      name: MTEB CQADupstackRetrieval
      type: mteb/cqadupstack
      config: default
      split: test
      revision: 4ffe81d471b1924886b33c7567bfb200e9eec5c4
    metrics:
    - type: ndcg_at_10
      value: 38.12183333333333
  - task:
      type: Retrieval
    dataset:
      name: MTEB CQADupstackStatsRetrieval
      type: mteb/cqadupstack-stats
      config: default
      split: test
      revision: 65ac3a16b8e91f9cee4c9828cc7c335575432a2a
    metrics:
    - type: ndcg_at_10
      value: 32.684000000000005
  - task:
      type: Retrieval
    dataset:
      name: MTEB CQADupstackTexRetrieval
      type: mteb/cqadupstack-tex
      config: default
      split: test
      revision: 46989137a86843e03a6195de44b09deda022eec7
    metrics:
    - type: ndcg_at_10
      value: 26.735
  - task:
      type: Retrieval
    dataset:
      name: MTEB CQADupstackUnixRetrieval
      type: mteb/cqadupstack-unix
      config: default
      split: test
      revision: 6c6430d3a6d36f8d2a829195bc5dc94d7e063e53
    metrics:
    - type: ndcg_at_10
      value: 36.933
  - task:
      type: Retrieval
    dataset:
      name: MTEB CQADupstackWebmastersRetrieval
      type: mteb/cqadupstack-webmasters
      config: default
      split: test
      revision: 160c094312a0e1facb97e55eeddb698c0abe3571
    metrics:
    - type: ndcg_at_10
      value: 33.747
  - task:
      type: Retrieval
    dataset:
      name: MTEB CQADupstackWordpressRetrieval
      type: mteb/cqadupstack-wordpress
      config: default
      split: test
      revision: 4ffe81d471b1924886b33c7567bfb200e9eec5c4
    metrics:
    - type: ndcg_at_10
      value: 28.872999999999998
  - task:
      type: Retrieval
    dataset:
      name: MTEB ClimateFEVER
      type: mteb/climate-fever
      config: default
      split: test
      revision: 47f2ac6acb640fc46020b02a5b59fdda04d39380
    metrics:
    - type: ndcg_at_10
      value: 34.833
  - task:
      type: Retrieval
    dataset:
      name: MTEB CmedqaRetrieval
      type: C-MTEB/CmedqaRetrieval
      config: default
      split: dev
      revision: cd540c506dae1cf9e9a59c3e06f42030d54e7301
    metrics:
    - type: ndcg_at_10
      value: 43.78
  - task:
      type: PairClassification
    dataset:
      name: MTEB Cmnli
      type: C-MTEB/CMNLI
      config: default
      split: validation
      revision: 41bc36f332156f7adc9e38f53777c959b2ae9766
    metrics:
    - type: cos_sim_ap
      value: 84.00640599186677
  - task:
      type: Retrieval
    dataset:
      name: MTEB CovidRetrieval
      type: C-MTEB/CovidRetrieval
      config: default
      split: dev
      revision: 1271c7809071a13532e05f25fb53511ffce77117
    metrics:
    - type: ndcg_at_10
      value: 80.60000000000001
  - task:
      type: Retrieval
    dataset:
      name: MTEB DBPedia
      type: mteb/dbpedia
      config: default
      split: test
      revision: c0f706b76e590d620bd6618b3ca8efdd34e2d659
    metrics:
    - type: ndcg_at_10
      value: 40.116
  - task:
      type: Retrieval
    dataset:
      name: MTEB DBPedia-PL
      type: clarin-knext/dbpedia-pl
      config: default
      split: test
      revision: 76afe41d9af165cc40999fcaa92312b8b012064a
    metrics:
    - type: ndcg_at_10
      value: 32.498
  - task:
      type: Retrieval
    dataset:
      name: MTEB DuRetrieval
      type: C-MTEB/DuRetrieval
      config: default
      split: dev
      revision: a1a333e290fe30b10f3f56498e3a0d911a693ced
    metrics:
    - type: ndcg_at_10
      value: 87.547
  - task:
      type: Retrieval
    dataset:
      name: MTEB EcomRetrieval
      type: C-MTEB/EcomRetrieval
      config: default
      split: dev
      revision: 687de13dc7294d6fd9be10c6945f9e8fec8166b9
    metrics:
    - type: ndcg_at_10
      value: 64.85
  - task:
      type: Classification
    dataset:
      name: MTEB EmotionClassification
      type: mteb/emotion
      config: default
      split: test
      revision: 4f58c6b202a23cf9a4da393831edf4f9183cad37
    metrics:
    - type: accuracy
      value: 47.949999999999996
  - task:
      type: Retrieval
    dataset:
      name: MTEB FEVER
      type: mteb/fever
      config: default
      split: test
      revision: bea83ef9e8fb933d90a2f1d5515737465d613e12
    metrics:
    - type: ndcg_at_10
      value: 92.111
  - task:
      type: Retrieval
    dataset:
      name: MTEB FiQA-PL
      type: clarin-knext/fiqa-pl
      config: default
      split: test
      revision: 2e535829717f8bf9dc829b7f911cc5bbd4e6608e
    metrics:
    - type: ndcg_at_10
      value: 28.962
  - task:
      type: Retrieval
    dataset:
      name: MTEB FiQA2018
      type: mteb/fiqa
      config: default
      split: test
      revision: 27a168819829fe9bcd655c2df245fb19452e8e06
    metrics:
    - type: ndcg_at_10
      value: 45.005
  - task:
      type: Clustering
    dataset:
      name: MTEB HALClusteringS2S
      type: lyon-nlp/clustering-hal-s2s
      config: default
      split: test
      revision: e06ebbbb123f8144bef1a5d18796f3dec9ae2915
    metrics:
    - type: v_measure
      value: 25.133776435657595
  - task:
      type: Retrieval
    dataset:
      name: MTEB HotpotQA
      type: mteb/hotpotqa
      config: default
      split: test
      revision: ab518f4d6fcca38d87c25209f94beba119d02014
    metrics:
    - type: ndcg_at_10
      value: 63.036
  - task:
      type: Retrieval
    dataset:
      name: MTEB HotpotQA-PL
      type: clarin-knext/hotpotqa-pl
      config: default
      split: test
      revision: a0bd479ac97b4ccb5bd6ce320c415d0bb4beb907
    metrics:
    - type: ndcg_at_10
      value: 56.904999999999994
  - task:
      type: Classification
    dataset:
      name: MTEB IFlyTek
      type: C-MTEB/IFlyTek-classification
      config: default
      split: validation
      revision: 421605374b29664c5fc098418fe20ada9bd55f8a
    metrics:
    - type: accuracy
      value: 44.59407464409388
  - task:
      type: Classification
    dataset:
      name: MTEB ImdbClassification
      type: mteb/imdb
      config: default
      split: test
      revision: 3d86128a09e091d6018b6d26cad27f2739fc2db7
    metrics:
    - type: accuracy
      value: 74.912
  - task:
      type: Classification
    dataset:
      name: MTEB JDReview
      type: C-MTEB/JDReview-classification
      config: default
      split: test
      revision: b7c64bd89eb87f8ded463478346f76731f07bf8b
    metrics:
    - type: accuracy
      value: 79.26829268292683
  - task:
      type: STS
    dataset:
      name: MTEB LCQMC
      type: C-MTEB/LCQMC
      config: default
      split: test
      revision: 17f9b096f80380fce5ed12a9be8be7784b337daf
    metrics:
    - type: cos_sim_spearman
      value: 74.8601229809791
  - task:
      type: Clustering
    dataset:
      name: MTEB MLSUMClusteringP2P
      type: mlsum
      config: default
      split: test
      revision: b5d54f8f3b61ae17845046286940f03c6bc79bc7
    metrics:
    - type: v_measure
      value: 42.331902754246556
    - type: v_measure
      value: 40.92029335502153
  - task:
      type: Reranking
    dataset:
      name: MTEB MMarcoReranking
      type: C-MTEB/Mmarco-reranking
      config: default
      split: dev
      revision: 8e0c766dbe9e16e1d221116a3f36795fbade07f6
    metrics:
    - type: map
      value: 32.19266316591337
  - task:
      type: Retrieval
    dataset:
      name: MTEB MMarcoRetrieval
      type: C-MTEB/MMarcoRetrieval
      config: default
      split: dev
      revision: 539bbde593d947e2a124ba72651aafc09eb33fc2
    metrics:
    - type: ndcg_at_10
      value: 79.346
  - task:
      type: Retrieval
    dataset:
      name: MTEB MSMARCO
      type: mteb/msmarco
      config: default
      split: dev
      revision: c5a29a104738b98a9e76336939199e264163d4a0
    metrics:
    - type: ndcg_at_10
      value: 39.922999999999995
  - task:
      type: Retrieval
    dataset:
      name: MTEB MSMARCO-PL
      type: clarin-knext/msmarco-pl
      config: default
      split: test
      revision: 8634c07806d5cce3a6138e260e59b81760a0a640
    metrics:
    - type: ndcg_at_10
      value: 55.620999999999995
  - task:
      type: Classification
    dataset:
      name: MTEB MTOPDomainClassification (en)
      type: mteb/mtop_domain
      config: en
      split: test
      revision: d80d48c1eb48d3562165c59d59d0034df9fff0bf
    metrics:
    - type: accuracy
      value: 92.53989968080255
  - task:
      type: Classification
    dataset:
      name: MTEB MTOPDomainClassification (de)
      type: mteb/mtop_domain
      config: de
      split: test
      revision: d80d48c1eb48d3562165c59d59d0034df9fff0bf
    metrics:
    - type: accuracy
      value: 88.26993519301212
  - task:
      type: Classification
    dataset:
      name: MTEB MTOPDomainClassification (es)
      type: mteb/mtop_domain
      config: es
      split: test
      revision: d80d48c1eb48d3562165c59d59d0034df9fff0bf
    metrics:
    - type: accuracy
      value: 90.87725150100067
  - task:
      type: Classification
    dataset:
      name: MTEB MTOPDomainClassification (fr)
      type: mteb/mtop_domain
      config: fr
      split: test
      revision: d80d48c1eb48d3562165c59d59d0034df9fff0bf
    metrics:
    - type: accuracy
      value: 87.48512370811149
  - task:
      type: Classification
    dataset:
      name: MTEB MTOPDomainClassification (hi)
      type: mteb/mtop_domain
      config: hi
      split: test
      revision: d80d48c1eb48d3562165c59d59d0034df9fff0bf
    metrics:
    - type: accuracy
      value: 89.45141627823591
  - task:
      type: Classification
    dataset:
      name: MTEB MTOPDomainClassification (th)
      type: mteb/mtop_domain
      config: th
      split: test
      revision: d80d48c1eb48d3562165c59d59d0034df9fff0bf
    metrics:
    - type: accuracy
      value: 83.45750452079565
  - task:
      type: Classification
    dataset:
      name: MTEB MTOPIntentClassification (en)
      type: mteb/mtop_intent
      config: en
      split: test
      revision: ae001d0e6b1228650b7bd1c2c65fb50ad11a8aba
    metrics:
    - type: accuracy
      value: 72.57637938896488
  - task:
      type: Classification
    dataset:
      name: MTEB MTOPIntentClassification (de)
      type: mteb/mtop_intent
      config: de
      split: test
      revision: ae001d0e6b1228650b7bd1c2c65fb50ad11a8aba
    metrics:
    - type: accuracy
      value: 63.50803043110736
  - task:
      type: Classification
    dataset:
      name: MTEB MTOPIntentClassification (es)
      type: mteb/mtop_intent
      config: es
      split: test
      revision: ae001d0e6b1228650b7bd1c2c65fb50ad11a8aba
    metrics:
    - type: accuracy
      value: 71.6577718478986
  - task:
      type: Classification
    dataset:
      name: MTEB MTOPIntentClassification (fr)
      type: mteb/mtop_intent
      config: fr
      split: test
      revision: ae001d0e6b1228650b7bd1c2c65fb50ad11a8aba
    metrics:
    - type: accuracy
      value: 64.05887879736925
  - task:
      type: Classification
    dataset:
      name: MTEB MTOPIntentClassification (hi)
      type: mteb/mtop_intent
      config: hi
      split: test
      revision: ae001d0e6b1228650b7bd1c2c65fb50ad11a8aba
    metrics:
    - type: accuracy
      value: 65.27070634636071
  - task:
      type: Classification
    dataset:
      name: MTEB MTOPIntentClassification (th)
      type: mteb/mtop_intent
      config: th
      split: test
      revision: ae001d0e6b1228650b7bd1c2c65fb50ad11a8aba
    metrics:
    - type: accuracy
      value: 63.04520795660037
  - task:
      type: Classification
    dataset:
      name: MTEB MasakhaNEWSClassification (fra)
      type: masakhane/masakhanews
      config: fra
      split: test
      revision: 8ccc72e69e65f40c70e117d8b3c08306bb788b60
    metrics:
    - type: accuracy
      value: 80.66350710900474
  - task:
      type: Clustering
    dataset:
      name: MTEB MasakhaNEWSClusteringP2P (fra)
      type: masakhane/masakhanews
      config: fra
      split: test
      revision: 8ccc72e69e65f40c70e117d8b3c08306bb788b60
    metrics:
    - type: v_measure
      value: 44.016506455899425
    - type: v_measure
      value: 40.67730129573544
  - task:
      type: Classification
    dataset:
      name: MTEB MassiveIntentClassification (af)
      type: mteb/amazon_massive_intent
      config: af
      split: test
      revision: 31efe3c427b0bae9c22cbb560b8f15491cc6bed7
    metrics:
    - type: accuracy
      value: 57.94552790854068
  - task:
      type: Classification
    dataset:
      name: MTEB MassiveIntentClassification (am)
      type: mteb/amazon_massive_intent
      config: am
      split: test
      revision: 31efe3c427b0bae9c22cbb560b8f15491cc6bed7
    metrics:
    - type: accuracy
      value: 49.273705447209146
  - task:
      type: Classification
    dataset:
      name: MTEB MassiveIntentClassification (ar)
      type: mteb/amazon_massive_intent
      config: ar
      split: test
      revision: 31efe3c427b0bae9c22cbb560b8f15491cc6bed7
    metrics:
    - type: accuracy
      value: 55.490921318090116
  - task:
      type: Classification
    dataset:
      name: MTEB MassiveIntentClassification (az)
      type: mteb/amazon_massive_intent
      config: az
      split: test
      revision: 31efe3c427b0bae9c22cbb560b8f15491cc6bed7
    metrics:
    - type: accuracy
      value: 60.97511768661733
  - task:
      type: Classification
    dataset:
      name: MTEB MassiveIntentClassification (bn)
      type: mteb/amazon_massive_intent
      config: bn
      split: test
      revision: 31efe3c427b0bae9c22cbb560b8f15491cc6bed7
    metrics:
    - type: accuracy
      value: 57.5689307330195
  - task:
      type: Classification
    dataset:
      name: MTEB MassiveIntentClassification (cy)
      type: mteb/amazon_massive_intent
      config: cy
      split: test
      revision: 31efe3c427b0bae9c22cbb560b8f15491cc6bed7
    metrics:
    - type: accuracy
      value: 48.34902488231337
  - task:
      type: Classification
    dataset:
      name: MTEB MassiveIntentClassification (da)
      type: mteb/amazon_massive_intent
      config: da
      split: test
      revision: 31efe3c427b0bae9c22cbb560b8f15491cc6bed7
    metrics:
    - type: accuracy
      value: 63.6684599865501
  - task:
      type: Classification
    dataset:
      name: MTEB MassiveIntentClassification (de)
      type: mteb/amazon_massive_intent
      config: de
      split: test
      revision: 31efe3c427b0bae9c22cbb560b8f15491cc6bed7
    metrics:
    - type: accuracy
      value: 62.54539340954942
  - task:
      type: Classification
    dataset:
      name: MTEB MassiveIntentClassification (el)
      type: mteb/amazon_massive_intent
      config: el
      split: test
      revision: 31efe3c427b0bae9c22cbb560b8f15491cc6bed7
    metrics:
    - type: accuracy
      value: 63.08675184936112
  - task:
      type: Classification
    dataset:
      name: MTEB MassiveIntentClassification (en)
      type: mteb/amazon_massive_intent
      config: en
      split: test
      revision: 31efe3c427b0bae9c22cbb560b8f15491cc6bed7
    metrics:
    - type: accuracy
      value: 72.12508406186953
  - task:
      type: Classification
    dataset:
      name: MTEB MassiveIntentClassification (es)
      type: mteb/amazon_massive_intent
      config: es
      split: test
      revision: 31efe3c427b0bae9c22cbb560b8f15491cc6bed7
    metrics:
    - type: accuracy
      value: 67.41425689307331
  - task:
      type: Classification
    dataset:
      name: MTEB MassiveIntentClassification (fa)
      type: mteb/amazon_massive_intent
      config: fa
      split: test
      revision: 31efe3c427b0bae9c22cbb560b8f15491cc6bed7
    metrics:
    - type: accuracy
      value: 65.59515803631474
  - task:
      type: Classification
    dataset:
      name: MTEB MassiveIntentClassification (fi)
      type: mteb/amazon_massive_intent
      config: fi
      split: test
      revision: 31efe3c427b0bae9c22cbb560b8f15491cc6bed7
    metrics:
    - type: accuracy
      value: 62.90517821116342
  - task:
      type: Classification
    dataset:
      name: MTEB MassiveIntentClassification (fr)
      type: mteb/amazon_massive_intent
      config: fr
      split: test
      revision: 31efe3c427b0bae9c22cbb560b8f15491cc6bed7
    metrics:
    - type: accuracy
      value: 67.91526563550774
  - task:
      type: Classification
    dataset:
      name: MTEB MassiveIntentClassification (he)
      type: mteb/amazon_massive_intent
      config: he
      split: test
      revision: 31efe3c427b0bae9c22cbb560b8f15491cc6bed7
    metrics:
    - type: accuracy
      value: 55.198386012104905
  - task:
      type: Classification
    dataset:
      name: MTEB MassiveIntentClassification (hi)
      type: mteb/amazon_massive_intent
      config: hi
      split: test
      revision: 31efe3c427b0bae9c22cbb560b8f15491cc6bed7
    metrics:
    - type: accuracy
      value: 65.04371217215869
  - task:
      type: Classification
    dataset:
      name: MTEB MassiveIntentClassification (hu)
      type: mteb/amazon_massive_intent
      config: hu
      split: test
      revision: 31efe3c427b0bae9c22cbb560b8f15491cc6bed7
    metrics:
    - type: accuracy
      value: 63.31203765971756
  - task:
      type: Classification
    dataset:
      name: MTEB MassiveIntentClassification (hy)
      type: mteb/amazon_massive_intent
      config: hy
      split: test
      revision: 31efe3c427b0bae9c22cbb560b8f15491cc6bed7
    metrics:
    - type: accuracy
      value: 55.521183591123055
  - task:
      type: Classification
    dataset:
      name: MTEB MassiveIntentClassification (id)
      type: mteb/amazon_massive_intent
      config: id
      split: test
      revision: 31efe3c427b0bae9c22cbb560b8f15491cc6bed7
    metrics:
    - type: accuracy
      value: 66.06254203093476
  - task:
      type: Classification
    dataset:
      name: MTEB MassiveIntentClassification (is)
      type: mteb/amazon_massive_intent
      config: is
      split: test
      revision: 31efe3c427b0bae9c22cbb560b8f15491cc6bed7
    metrics:
    - type: accuracy
      value: 56.01546738399461
  - task:
      type: Classification
    dataset:
      name: MTEB MassiveIntentClassification (it)
      type: mteb/amazon_massive_intent
      config: it
      split: test
      revision: 31efe3c427b0bae9c22cbb560b8f15491cc6bed7
    metrics:
    - type: accuracy
      value: 67.27975790181574
  - task:
      type: Classification
    dataset:
      name: MTEB MassiveIntentClassification (ja)
      type: mteb/amazon_massive_intent
      config: ja
      split: test
      revision: 31efe3c427b0bae9c22cbb560b8f15491cc6bed7
    metrics:
    - type: accuracy
      value: 66.79556153328849
  - task:
      type: Classification
    dataset:
      name: MTEB MassiveIntentClassification (jv)
      type: mteb/amazon_massive_intent
      config: jv
      split: test
      revision: 31efe3c427b0bae9c22cbb560b8f15491cc6bed7
    metrics:
    - type: accuracy
      value: 50.18493611297915
  - task:
      type: Classification
    dataset:
      name: MTEB MassiveIntentClassification (ka)
      type: mteb/amazon_massive_intent
      config: ka
      split: test
      revision: 31efe3c427b0bae9c22cbb560b8f15491cc6bed7
    metrics:
    - type: accuracy
      value: 47.888365837256224
  - task:
      type: Classification
    dataset:
      name: MTEB MassiveIntentClassification (km)
      type: mteb/amazon_massive_intent
      config: km
      split: test
      revision: 31efe3c427b0bae9c22cbb560b8f15491cc6bed7
    metrics:
    - type: accuracy
      value: 50.79690652320108
  - task:
      type: Classification
    dataset:
      name: MTEB MassiveIntentClassification (kn)
      type: mteb/amazon_massive_intent
      config: kn
      split: test
      revision: 31efe3c427b0bae9c22cbb560b8f15491cc6bed7
    metrics:
    - type: accuracy
      value: 57.225958305312716
  - task:
      type: Classification
    dataset:
      name: MTEB MassiveIntentClassification (ko)
      type: mteb/amazon_massive_intent
      config: ko
      split: test
      revision: 31efe3c427b0bae9c22cbb560b8f15491cc6bed7
    metrics:
    - type: accuracy
      value: 64.58641560188299
  - task:
      type: Classification
    dataset:
      name: MTEB MassiveIntentClassification (lv)
      type: mteb/amazon_massive_intent
      config: lv
      split: test
      revision: 31efe3c427b0bae9c22cbb560b8f15491cc6bed7
    metrics:
    - type: accuracy
      value: 59.08204438466711
  - task:
      type: Classification
    dataset:
      name: MTEB MassiveIntentClassification (ml)
      type: mteb/amazon_massive_intent
      config: ml
      split: test
      revision: 31efe3c427b0bae9c22cbb560b8f15491cc6bed7
    metrics:
    - type: accuracy
      value: 59.54606590450572
  - task:
      type: Classification
    dataset:
      name: MTEB MassiveIntentClassification (mn)
      type: mteb/amazon_massive_intent
      config: mn
      split: test
      revision: 31efe3c427b0bae9c22cbb560b8f15491cc6bed7
    metrics:
    - type: accuracy
      value: 53.443174176193665
  - task:
      type: Classification
    dataset:
      name: MTEB MassiveIntentClassification (ms)
      type: mteb/amazon_massive_intent
      config: ms
      split: test
      revision: 31efe3c427b0bae9c22cbb560b8f15491cc6bed7
    metrics:
    - type: accuracy
      value: 61.65097511768661
  - task:
      type: Classification
    dataset:
      name: MTEB MassiveIntentClassification (my)
      type: mteb/amazon_massive_intent
      config: my
      split: test
      revision: 31efe3c427b0bae9c22cbb560b8f15491cc6bed7
    metrics:
    - type: accuracy
      value: 53.45662407531944
  - task:
      type: Classification
    dataset:
      name: MTEB MassiveIntentClassification (nb)
      type: mteb/amazon_massive_intent
      config: nb
      split: test
      revision: 31efe3c427b0bae9c22cbb560b8f15491cc6bed7
    metrics:
    - type: accuracy
      value: 63.739071956960316
  - task:
      type: Classification
    dataset:
      name: MTEB MassiveIntentClassification (nl)
      type: mteb/amazon_massive_intent
      config: nl
      split: test
      revision: 31efe3c427b0bae9c22cbb560b8f15491cc6bed7
    metrics:
    - type: accuracy
      value: 66.36180228648286
  - task:
      type: Classification
    dataset:
      name: MTEB MassiveIntentClassification (pl)
      type: mteb/amazon_massive_intent
      config: pl
      split: test
      revision: 31efe3c427b0bae9c22cbb560b8f15491cc6bed7
    metrics:
    - type: accuracy
      value: 66.3920645595158
  - task:
      type: Classification
    dataset:
      name: MTEB MassiveIntentClassification (pt)
      type: mteb/amazon_massive_intent
      config: pt
      split: test
      revision: 31efe3c427b0bae9c22cbb560b8f15491cc6bed7
    metrics:
    - type: accuracy
      value: 68.06993947545395
  - task:
      type: Classification
    dataset:
      name: MTEB MassiveIntentClassification (ro)
      type: mteb/amazon_massive_intent
      config: ro
      split: test
      revision: 31efe3c427b0bae9c22cbb560b8f15491cc6bed7
    metrics:
    - type: accuracy
      value: 63.123739071956955
  - task:
      type: Classification
    dataset:
      name: MTEB MassiveIntentClassification (ru)
      type: mteb/amazon_massive_intent
      config: ru
      split: test
      revision: 31efe3c427b0bae9c22cbb560b8f15491cc6bed7
    metrics:
    - type: accuracy
      value: 67.46133154001346
  - task:
      type: Classification
    dataset:
      name: MTEB MassiveIntentClassification (sl)
      type: mteb/amazon_massive_intent
      config: sl
      split: test
      revision: 31efe3c427b0bae9c22cbb560b8f15491cc6bed7
    metrics:
    - type: accuracy
      value: 60.54472091459314
  - task:
      type: Classification
    dataset:
      name: MTEB MassiveIntentClassification (sq)
      type: mteb/amazon_massive_intent
      config: sq
      split: test
      revision: 31efe3c427b0bae9c22cbb560b8f15491cc6bed7
    metrics:
    - type: accuracy
      value: 58.204438466711494
  - task:
      type: Classification
    dataset:
      name: MTEB MassiveIntentClassification (sv)
      type: mteb/amazon_massive_intent
      config: sv
      split: test
      revision: 31efe3c427b0bae9c22cbb560b8f15491cc6bed7
    metrics:
    - type: accuracy
      value: 65.69603227975792
  - task:
      type: Classification
    dataset:
      name: MTEB MassiveIntentClassification (sw)
      type: mteb/amazon_massive_intent
      config: sw
      split: test
      revision: 31efe3c427b0bae9c22cbb560b8f15491cc6bed7
    metrics:
    - type: accuracy
      value: 51.684599865501
  - task:
      type: Classification
    dataset:
      name: MTEB MassiveIntentClassification (ta)
      type: mteb/amazon_massive_intent
      config: ta
      split: test
      revision: 31efe3c427b0bae9c22cbb560b8f15491cc6bed7
    metrics:
    - type: accuracy
      value: 58.523873570948226
  - task:
      type: Classification
    dataset:
      name: MTEB MassiveIntentClassification (te)
      type: mteb/amazon_massive_intent
      config: te
      split: test
      revision: 31efe3c427b0bae9c22cbb560b8f15491cc6bed7
    metrics:
    - type: accuracy
      value: 58.53396099529253
  - task:
      type: Classification
    dataset:
      name: MTEB MassiveIntentClassification (th)
      type: mteb/amazon_massive_intent
      config: th
      split: test
      revision: 31efe3c427b0bae9c22cbb560b8f15491cc6bed7
    metrics:
    - type: accuracy
      value: 61.88298587760591
  - task:
      type: Classification
    dataset:
      name: MTEB MassiveIntentClassification (tl)
      type: mteb/amazon_massive_intent
      config: tl
      split: test
      revision: 31efe3c427b0bae9c22cbb560b8f15491cc6bed7
    metrics:
    - type: accuracy
      value: 56.65097511768662
  - task:
      type: Classification
    dataset:
      name: MTEB MassiveIntentClassification (tr)
      type: mteb/amazon_massive_intent
      config: tr
      split: test
      revision: 31efe3c427b0bae9c22cbb560b8f15491cc6bed7
    metrics:
    - type: accuracy
      value: 64.8453261600538
  - task:
      type: Classification
    dataset:
      name: MTEB MassiveIntentClassification (ur)
      type: mteb/amazon_massive_intent
      config: ur
      split: test
      revision: 31efe3c427b0bae9c22cbb560b8f15491cc6bed7
    metrics:
    - type: accuracy
      value: 58.6247478143914
  - task:
      type: Classification
    dataset:
      name: MTEB MassiveIntentClassification (vi)
      type: mteb/amazon_massive_intent
      config: vi
      split: test
      revision: 31efe3c427b0bae9c22cbb560b8f15491cc6bed7
    metrics:
    - type: accuracy
      value: 64.16274377942166
  - task:
      type: Classification
    dataset:
      name: MTEB MassiveIntentClassification (zh-CN)
      type: mteb/amazon_massive_intent
      config: zh-CN
      split: test
      revision: 31efe3c427b0bae9c22cbb560b8f15491cc6bed7
    metrics:
    - type: accuracy
      value: 69.61667787491594
  - task:
      type: Classification
    dataset:
      name: MTEB MassiveIntentClassification (zh-TW)
      type: mteb/amazon_massive_intent
      config: zh-TW
      split: test
      revision: 31efe3c427b0bae9c22cbb560b8f15491cc6bed7
    metrics:
    - type: accuracy
      value: 64.17283120376598
  - task:
      type: Classification
    dataset:
      name: MTEB MassiveScenarioClassification (af)
      type: mteb/amazon_massive_scenario
      config: af
      split: test
      revision: 7d571f92784cd94a019292a1f45445077d0ef634
    metrics:
    - type: accuracy
      value: 64.89912575655683
  - task:
      type: Classification
    dataset:
      name: MTEB MassiveScenarioClassification (am)
      type: mteb/amazon_massive_scenario
      config: am
      split: test
      revision: 7d571f92784cd94a019292a1f45445077d0ef634
    metrics:
    - type: accuracy
      value: 57.27975790181573
  - task:
      type: Classification
    dataset:
      name: MTEB MassiveScenarioClassification (ar)
      type: mteb/amazon_massive_scenario
      config: ar
      split: test
      revision: 7d571f92784cd94a019292a1f45445077d0ef634
    metrics:
    - type: accuracy
      value: 62.269670477471415
  - task:
      type: Classification
    dataset:
      name: MTEB MassiveScenarioClassification (az)
      type: mteb/amazon_massive_scenario
      config: az
      split: test
      revision: 7d571f92784cd94a019292a1f45445077d0ef634
    metrics:
    - type: accuracy
      value: 65.10423671822461
  - task:
      type: Classification
    dataset:
      name: MTEB MassiveScenarioClassification (bn)
      type: mteb/amazon_massive_scenario
      config: bn
      split: test
      revision: 7d571f92784cd94a019292a1f45445077d0ef634
    metrics:
    - type: accuracy
      value: 62.40753194351043
  - task:
      type: Classification
    dataset:
      name: MTEB MassiveScenarioClassification (cy)
      type: mteb/amazon_massive_scenario
      config: cy
      split: test
      revision: 7d571f92784cd94a019292a1f45445077d0ef634
    metrics:
    - type: accuracy
      value: 55.369872225958304
  - task:
      type: Classification
    dataset:
      name: MTEB MassiveScenarioClassification (da)
      type: mteb/amazon_massive_scenario
      config: da
      split: test
      revision: 7d571f92784cd94a019292a1f45445077d0ef634
    metrics:
    - type: accuracy
      value: 71.60726294552792
  - task:
      type: Classification
    dataset:
      name: MTEB MassiveScenarioClassification (de)
      type: mteb/amazon_massive_scenario
      config: de
      split: test
      revision: 7d571f92784cd94a019292a1f45445077d0ef634
    metrics:
    - type: accuracy
      value: 70.30262273032952
  - task:
      type: Classification
    dataset:
      name: MTEB MassiveScenarioClassification (el)
      type: mteb/amazon_massive_scenario
      config: el
      split: test
      revision: 7d571f92784cd94a019292a1f45445077d0ef634
    metrics:
    - type: accuracy
      value: 69.52925353059851
  - task:
      type: Classification
    dataset:
      name: MTEB MassiveScenarioClassification (en)
      type: mteb/amazon_massive_scenario
      config: en
      split: test
      revision: 7d571f92784cd94a019292a1f45445077d0ef634
    metrics:
    - type: accuracy
      value: 76.28446536650976
  - task:
      type: Classification
    dataset:
      name: MTEB MassiveScenarioClassification (es)
      type: mteb/amazon_massive_scenario
      config: es
      split: test
      revision: 7d571f92784cd94a019292a1f45445077d0ef634
    metrics:
    - type: accuracy
      value: 72.45460659045058
  - task:
      type: Classification
    dataset:
      name: MTEB MassiveScenarioClassification (fa)
      type: mteb/amazon_massive_scenario
      config: fa
      split: test
      revision: 7d571f92784cd94a019292a1f45445077d0ef634
    metrics:
    - type: accuracy
      value: 70.26563550773368
  - task:
      type: Classification
    dataset:
      name: MTEB MassiveScenarioClassification (fi)
      type: mteb/amazon_massive_scenario
      config: fi
      split: test
      revision: 7d571f92784cd94a019292a1f45445077d0ef634
    metrics:
    - type: accuracy
      value: 67.20578345662408
  - task:
      type: Classification
    dataset:
      name: MTEB MassiveScenarioClassification (fr)
      type: mteb/amazon_massive_scenario
      config: fr
      split: test
      revision: 7d571f92784cd94a019292a1f45445077d0ef634
    metrics:
    - type: accuracy
      value: 72.64963012777405
  - task:
      type: Classification
    dataset:
      name: MTEB MassiveScenarioClassification (he)
      type: mteb/amazon_massive_scenario
      config: he
      split: test
      revision: 7d571f92784cd94a019292a1f45445077d0ef634
    metrics:
    - type: accuracy
      value: 61.698049764626774
  - task:
      type: Classification
    dataset:
      name: MTEB MassiveScenarioClassification (hi)
      type: mteb/amazon_massive_scenario
      config: hi
      split: test
      revision: 7d571f92784cd94a019292a1f45445077d0ef634
    metrics:
    - type: accuracy
      value: 70.14458641560188
  - task:
      type: Classification
    dataset:
      name: MTEB MassiveScenarioClassification (hu)
      type: mteb/amazon_massive_scenario
      config: hu
      split: test
      revision: 7d571f92784cd94a019292a1f45445077d0ef634
    metrics:
    - type: accuracy
      value: 70.51445864156018
  - task:
      type: Classification
    dataset:
      name: MTEB MassiveScenarioClassification (hy)
      type: mteb/amazon_massive_scenario
      config: hy
      split: test
      revision: 7d571f92784cd94a019292a1f45445077d0ef634
    metrics:
    - type: accuracy
      value: 60.13786146603901
  - task:
      type: Classification
    dataset:
      name: MTEB MassiveScenarioClassification (id)
      type: mteb/amazon_massive_scenario
      config: id
      split: test
      revision: 7d571f92784cd94a019292a1f45445077d0ef634
    metrics:
    - type: accuracy
      value: 70.61533288500337
  - task:
      type: Classification
    dataset:
      name: MTEB MassiveScenarioClassification (is)
      type: mteb/amazon_massive_scenario
      config: is
      split: test
      revision: 7d571f92784cd94a019292a1f45445077d0ef634
    metrics:
    - type: accuracy
      value: 61.526563550773375
  - task:
      type: Classification
    dataset:
      name: MTEB MassiveScenarioClassification (it)
      type: mteb/amazon_massive_scenario
      config: it
      split: test
      revision: 7d571f92784cd94a019292a1f45445077d0ef634
    metrics:
    - type: accuracy
      value: 71.99731002017484
  - task:
      type: Classification
    dataset:
      name: MTEB MassiveScenarioClassification (ja)
      type: mteb/amazon_massive_scenario
      config: ja
      split: test
      revision: 7d571f92784cd94a019292a1f45445077d0ef634
    metrics:
    - type: accuracy
      value: 71.59381304640216
  - task:
      type: Classification
    dataset:
      name: MTEB MassiveScenarioClassification (jv)
      type: mteb/amazon_massive_scenario
      config: jv
      split: test
      revision: 7d571f92784cd94a019292a1f45445077d0ef634
    metrics:
    - type: accuracy
      value: 57.010759919300604
  - task:
      type: Classification
    dataset:
      name: MTEB MassiveScenarioClassification (ka)
      type: mteb/amazon_massive_scenario
      config: ka
      split: test
      revision: 7d571f92784cd94a019292a1f45445077d0ef634
    metrics:
    - type: accuracy
      value: 53.26160053799597
  - task:
      type: Classification
    dataset:
      name: MTEB MassiveScenarioClassification (km)
      type: mteb/amazon_massive_scenario
      config: km
      split: test
      revision: 7d571f92784cd94a019292a1f45445077d0ef634
    metrics:
    - type: accuracy
      value: 57.800941492938804
  - task:
      type: Classification
    dataset:
      name: MTEB MassiveScenarioClassification (kn)
      type: mteb/amazon_massive_scenario
      config: kn
      split: test
      revision: 7d571f92784cd94a019292a1f45445077d0ef634
    metrics:
    - type: accuracy
      value: 62.387357094821795
  - task:
      type: Classification
    dataset:
      name: MTEB MassiveScenarioClassification (ko)
      type: mteb/amazon_massive_scenario
      config: ko
      split: test
      revision: 7d571f92784cd94a019292a1f45445077d0ef634
    metrics:
    - type: accuracy
      value: 69.5359784801614
  - task:
      type: Classification
    dataset:
      name: MTEB MassiveScenarioClassification (lv)
      type: mteb/amazon_massive_scenario
      config: lv
      split: test
      revision: 7d571f92784cd94a019292a1f45445077d0ef634
    metrics:
    - type: accuracy
      value: 63.36919973100203
  - task:
      type: Classification
    dataset:
      name: MTEB MassiveScenarioClassification (ml)
      type: mteb/amazon_massive_scenario
      config: ml
      split: test
      revision: 7d571f92784cd94a019292a1f45445077d0ef634
    metrics:
    - type: accuracy
      value: 64.81506388702084
  - task:
      type: Classification
    dataset:
      name: MTEB MassiveScenarioClassification (mn)
      type: mteb/amazon_massive_scenario
      config: mn
      split: test
      revision: 7d571f92784cd94a019292a1f45445077d0ef634
    metrics:
    - type: accuracy
      value: 59.35104236718225
  - task:
      type: Classification
    dataset:
      name: MTEB MassiveScenarioClassification (ms)
      type: mteb/amazon_massive_scenario
      config: ms
      split: test
      revision: 7d571f92784cd94a019292a1f45445077d0ef634
    metrics:
    - type: accuracy
      value: 66.67787491593813
  - task:
      type: Classification
    dataset:
      name: MTEB MassiveScenarioClassification (my)
      type: mteb/amazon_massive_scenario
      config: my
      split: test
      revision: 7d571f92784cd94a019292a1f45445077d0ef634
    metrics:
    - type: accuracy
      value: 59.4250168123739
  - task:
      type: Classification
    dataset:
      name: MTEB MassiveScenarioClassification (nb)
      type: mteb/amazon_massive_scenario
      config: nb
      split: test
      revision: 7d571f92784cd94a019292a1f45445077d0ef634
    metrics:
    - type: accuracy
      value: 71.49630127774043
  - task:
      type: Classification
    dataset:
      name: MTEB MassiveScenarioClassification (nl)
      type: mteb/amazon_massive_scenario
      config: nl
      split: test
      revision: 7d571f92784cd94a019292a1f45445077d0ef634
    metrics:
    - type: accuracy
      value: 71.95696032279758
  - task:
      type: Classification
    dataset:
      name: MTEB MassiveScenarioClassification (pl)
      type: mteb/amazon_massive_scenario
      config: pl
      split: test
      revision: 7d571f92784cd94a019292a1f45445077d0ef634
    metrics:
    - type: accuracy
      value: 70.11768661735036
  - task:
      type: Classification
    dataset:
      name: MTEB MassiveScenarioClassification (pt)
      type: mteb/amazon_massive_scenario
      config: pt
      split: test
      revision: 7d571f92784cd94a019292a1f45445077d0ef634
    metrics:
    - type: accuracy
      value: 71.86953597848016
  - task:
      type: Classification
    dataset:
      name: MTEB MassiveScenarioClassification (ro)
      type: mteb/amazon_massive_scenario
      config: ro
      split: test
      revision: 7d571f92784cd94a019292a1f45445077d0ef634
    metrics:
    - type: accuracy
      value: 68.51042367182247
  - task:
      type: Classification
    dataset:
      name: MTEB MassiveScenarioClassification (ru)
      type: mteb/amazon_massive_scenario
      config: ru
      split: test
      revision: 7d571f92784cd94a019292a1f45445077d0ef634
    metrics:
    - type: accuracy
      value: 71.65097511768661
  - task:
      type: Classification
    dataset:
      name: MTEB MassiveScenarioClassification (sl)
      type: mteb/amazon_massive_scenario
      config: sl
      split: test
      revision: 7d571f92784cd94a019292a1f45445077d0ef634
    metrics:
    - type: accuracy
      value: 66.81573638197713
  - task:
      type: Classification
    dataset:
      name: MTEB MassiveScenarioClassification (sq)
      type: mteb/amazon_massive_scenario
      config: sq
      split: test
      revision: 7d571f92784cd94a019292a1f45445077d0ef634
    metrics:
    - type: accuracy
      value: 65.26227303295225
  - task:
      type: Classification
    dataset:
      name: MTEB MassiveScenarioClassification (sv)
      type: mteb/amazon_massive_scenario
      config: sv
      split: test
      revision: 7d571f92784cd94a019292a1f45445077d0ef634
    metrics:
    - type: accuracy
      value: 72.51513113651646
  - task:
      type: Classification
    dataset:
      name: MTEB MassiveScenarioClassification (sw)
      type: mteb/amazon_massive_scenario
      config: sw
      split: test
      revision: 7d571f92784cd94a019292a1f45445077d0ef634
    metrics:
    - type: accuracy
      value: 58.29858776059179
  - task:
      type: Classification
    dataset:
      name: MTEB MassiveScenarioClassification (ta)
      type: mteb/amazon_massive_scenario
      config: ta
      split: test
      revision: 7d571f92784cd94a019292a1f45445077d0ef634
    metrics:
    - type: accuracy
      value: 62.72696704774714
  - task:
      type: Classification
    dataset:
      name: MTEB MassiveScenarioClassification (te)
      type: mteb/amazon_massive_scenario
      config: te
      split: test
      revision: 7d571f92784cd94a019292a1f45445077d0ef634
    metrics:
    - type: accuracy
      value: 66.57700067249496
  - task:
      type: Classification
    dataset:
      name: MTEB MassiveScenarioClassification (th)
      type: mteb/amazon_massive_scenario
      config: th
      split: test
      revision: 7d571f92784cd94a019292a1f45445077d0ef634
    metrics:
    - type: accuracy
      value: 68.22797579018157
  - task:
      type: Classification
    dataset:
      name: MTEB MassiveScenarioClassification (tl)
      type: mteb/amazon_massive_scenario
      config: tl
      split: test
      revision: 7d571f92784cd94a019292a1f45445077d0ef634
    metrics:
    - type: accuracy
      value: 61.97041022192333
  - task:
      type: Classification
    dataset:
      name: MTEB MassiveScenarioClassification (tr)
      type: mteb/amazon_massive_scenario
      config: tr
      split: test
      revision: 7d571f92784cd94a019292a1f45445077d0ef634
    metrics:
    - type: accuracy
      value: 70.72629455279085
  - task:
      type: Classification
    dataset:
      name: MTEB MassiveScenarioClassification (ur)
      type: mteb/amazon_massive_scenario
      config: ur
      split: test
      revision: 7d571f92784cd94a019292a1f45445077d0ef634
    metrics:
    - type: accuracy
      value: 63.16072629455278
  - task:
      type: Classification
    dataset:
      name: MTEB MassiveScenarioClassification (vi)
      type: mteb/amazon_massive_scenario
      config: vi
      split: test
      revision: 7d571f92784cd94a019292a1f45445077d0ef634
    metrics:
    - type: accuracy
      value: 67.92199058507062
  - task:
      type: Classification
    dataset:
      name: MTEB MassiveScenarioClassification (zh-CN)
      type: mteb/amazon_massive_scenario
      config: zh-CN
      split: test
      revision: 7d571f92784cd94a019292a1f45445077d0ef634
    metrics:
    - type: accuracy
      value: 74.40484196368527
  - task:
      type: Classification
    dataset:
      name: MTEB MassiveScenarioClassification (zh-TW)
      type: mteb/amazon_massive_scenario
      config: zh-TW
      split: test
      revision: 7d571f92784cd94a019292a1f45445077d0ef634
    metrics:
    - type: accuracy
      value: 71.61398789509079
  - task:
      type: Retrieval
    dataset:
      name: MTEB MedicalRetrieval
      type: C-MTEB/MedicalRetrieval
      config: default
      split: dev
      revision: 2039188fb5800a9803ba5048df7b76e6fb151fc6
    metrics:
    - type: ndcg_at_10
      value: 61.934999999999995
  - task:
      type: Clustering
    dataset:
      name: MTEB MedrxivClusteringP2P
      type: mteb/medrxiv-clustering-p2p
      config: default
      split: test
      revision: e7a26af6f3ae46b30dde8737f02c07b1505bcc73
    metrics:
    - type: v_measure
      value: 33.052031054565205
  - task:
      type: Clustering
    dataset:
      name: MTEB MedrxivClusteringS2S
      type: mteb/medrxiv-clustering-s2s
      config: default
      split: test
      revision: 35191c8c0dca72d8ff3efcd72aa802307d469663
    metrics:
    - type: v_measure
      value: 31.969909524076794
  - task:
      type: Reranking
    dataset:
      name: MTEB MindSmallReranking
      type: mteb/mind_small
      config: default
      split: test
      revision: 3bdac13927fdc888b903db93b2ffdbd90b295a69
    metrics:
    - type: map
      value: 31.7530992892652
  - task:
      type: Retrieval
    dataset:
      name: MTEB MintakaRetrieval (fr)
      type: jinaai/mintakaqa
      config: fr
      split: test
      revision: efa78cc2f74bbcd21eff2261f9e13aebe40b814e
    metrics:
    - type: ndcg_at_10
      value: 34.705999999999996
  - task:
      type: Retrieval
    dataset:
      name: MTEB MultiLongDocRetrieval (ar)
      type: Shitao/MLDR
      config: ar
      split: test
      revision: None
    metrics:
    - type: ndcg_at_10
      value: 55.166000000000004
  - task:
      type: Retrieval
    dataset:
      name: MTEB MultiLongDocRetrieval (de)
      type: Shitao/MLDR
      config: de
      split: test
      revision: None
    metrics:
    - type: ndcg_at_10
      value: 55.155
  - task:
      type: Retrieval
    dataset:
      name: MTEB MultiLongDocRetrieval (en)
      type: Shitao/MLDR
      config: en
      split: test
      revision: None
    metrics:
    - type: ndcg_at_10
      value: 50.993
  - task:
      type: Retrieval
    dataset:
      name: MTEB MultiLongDocRetrieval (es)
      type: Shitao/MLDR
      config: es
      split: test
      revision: None
    metrics:
    - type: ndcg_at_10
      value: 81.228
  - task:
      type: Retrieval
    dataset:
      name: MTEB MultiLongDocRetrieval (fr)
      type: Shitao/MLDR
      config: fr
      split: test
      revision: None
    metrics:
    - type: ndcg_at_10
      value: 76.19
  - task:
      type: Retrieval
    dataset:
      name: MTEB MultiLongDocRetrieval (hi)
      type: Shitao/MLDR
      config: hi
      split: test
      revision: None
    metrics:
    - type: ndcg_at_10
      value: 45.206
  - task:
      type: Retrieval
    dataset:
      name: MTEB MultiLongDocRetrieval (it)
      type: Shitao/MLDR
      config: it
      split: test
      revision: None
    metrics:
    - type: ndcg_at_10
      value: 66.741
  - task:
      type: Retrieval
    dataset:
      name: MTEB MultiLongDocRetrieval (ja)
      type: Shitao/MLDR
      config: ja
      split: test
      revision: None
    metrics:
    - type: ndcg_at_10
      value: 52.111
  - task:
      type: Retrieval
    dataset:
      name: MTEB MultiLongDocRetrieval (ko)
      type: Shitao/MLDR
      config: ko
      split: test
      revision: None
    metrics:
    - type: ndcg_at_10
      value: 46.733000000000004
  - task:
      type: Retrieval
    dataset:
      name: MTEB MultiLongDocRetrieval (pt)
      type: Shitao/MLDR
      config: pt
      split: test
      revision: None
    metrics:
    - type: ndcg_at_10
      value: 79.105
  - task:
      type: Retrieval
    dataset:
      name: MTEB MultiLongDocRetrieval (ru)
      type: Shitao/MLDR
      config: ru
      split: test
      revision: None
    metrics:
    - type: ndcg_at_10
      value: 64.21
  - task:
      type: Retrieval
    dataset:
      name: MTEB MultiLongDocRetrieval (th)
      type: Shitao/MLDR
      config: th
      split: test
      revision: None
    metrics:
    - type: ndcg_at_10
      value: 35.467
  - task:
      type: Retrieval
    dataset:
      name: MTEB MultiLongDocRetrieval (zh)
      type: Shitao/MLDR
      config: zh
      split: test
      revision: None
    metrics:
    - type: ndcg_at_10
      value: 27.419
  - task:
      type: Classification
    dataset:
      name: MTEB MultilingualSentiment
      type: C-MTEB/MultilingualSentiment-classification
      config: default
      split: validation
      revision: 46958b007a63fdbf239b7672c25d0bea67b5ea1a
    metrics:
    - type: accuracy
      value: 61.02000000000001
  - task:
      type: Retrieval
    dataset:
      name: MTEB NFCorpus
      type: mteb/nfcorpus
      config: default
      split: test
      revision: ec0fa4fe99da2ff19ca1214b7966684033a58814
    metrics:
    - type: ndcg_at_10
      value: 36.65
  - task:
      type: Retrieval
    dataset:
      name: MTEB NFCorpus-PL
      type: clarin-knext/nfcorpus-pl
      config: default
      split: test
      revision: 9a6f9567fda928260afed2de480d79c98bf0bec0
    metrics:
    - type: ndcg_at_10
      value: 26.831
  - task:
      type: Retrieval
    dataset:
      name: MTEB NQ
      type: mteb/nq
      config: default
      split: test
      revision: b774495ed302d8c44a3a7ea25c90dbce03968f31
    metrics:
    - type: ndcg_at_10
      value: 58.111000000000004
  - task:
      type: Retrieval
    dataset:
      name: MTEB NQ-PL
      type: clarin-knext/nq-pl
      config: default
      split: test
      revision: f171245712cf85dd4700b06bef18001578d0ca8d
    metrics:
    - type: ndcg_at_10
      value: 43.126999999999995
  - task:
      type: PairClassification
    dataset:
      name: MTEB Ocnli
      type: C-MTEB/OCNLI
      config: default
      split: validation
      revision: 66e76a618a34d6d565d5538088562851e6daa7ec
    metrics:
    - type: cos_sim_ap
      value: 72.67630697316041
  - task:
      type: Classification
    dataset:
      name: MTEB OnlineShopping
      type: C-MTEB/OnlineShopping-classification
      config: default
      split: test
      revision: e610f2ebd179a8fda30ae534c3878750a96db120
    metrics:
    - type: accuracy
      value: 84.85000000000001
  - task:
      type: PairClassification
    dataset:
      name: MTEB OpusparcusPC (fr)
      type: GEM/opusparcus
      config: fr
      split: test
      revision: 9e9b1f8ef51616073f47f306f7f47dd91663f86a
    metrics:
    - type: cos_sim_ap
      value: 100
  - task:
      type: Classification
    dataset:
      name: MTEB PAC
      type: laugustyniak/abusive-clauses-pl
      config: default
      split: test
      revision: None
    metrics:
    - type: accuracy
      value: 65.99189110918043
  - task:
      type: STS
    dataset:
      name: MTEB PAWSX
      type: C-MTEB/PAWSX
      config: default
      split: test
      revision: 9c6a90e430ac22b5779fb019a23e820b11a8b5e1
    metrics:
    - type: cos_sim_spearman
      value: 16.124364530596228
  - task:
      type: PairClassification
    dataset:
      name: MTEB PPC
      type: PL-MTEB/ppc-pairclassification
      config: default
      split: test
      revision: None
    metrics:
    - type: cos_sim_ap
      value: 92.43431057460192
  - task:
      type: PairClassification
    dataset:
      name: MTEB PSC
      type: PL-MTEB/psc-pairclassification
      config: default
      split: test
      revision: None
    metrics:
    - type: cos_sim_ap
      value: 99.06090138049724
  - task:
      type: PairClassification
    dataset:
      name: MTEB PawsX (fr)
      type: paws-x
      config: fr
      split: test
      revision: 8a04d940a42cd40658986fdd8e3da561533a3646
    metrics:
    - type: cos_sim_ap
      value: 58.9314954874314
  - task:
      type: Classification
    dataset:
      name: MTEB PolEmo2.0-IN
      type: PL-MTEB/polemo2_in
      config: default
      split: test
      revision: None
    metrics:
    - type: accuracy
      value: 69.59833795013851
  - task:
      type: Classification
    dataset:
      name: MTEB PolEmo2.0-OUT
      type: PL-MTEB/polemo2_out
      config: default
      split: test
      revision: None
    metrics:
    - type: accuracy
      value: 44.73684210526315
  - task:
      type: STS
    dataset:
      name: MTEB QBQTC
      type: C-MTEB/QBQTC
      config: default
      split: test
      revision: 790b0510dc52b1553e8c49f3d2afb48c0e5c48b7
    metrics:
    - type: cos_sim_spearman
      value: 39.36450754137984
  - task:
      type: Retrieval
    dataset:
      name: MTEB Quora-PL
      type: clarin-knext/quora-pl
      config: default
      split: test
      revision: 0be27e93455051e531182b85e85e425aba12e9d4
    metrics:
    - type: ndcg_at_10
      value: 80.76299999999999
  - task:
      type: Retrieval
    dataset:
      name: MTEB QuoraRetrieval
      type: mteb/quora
      config: default
      split: test
      revision: None
    metrics:
    - type: ndcg_at_10
      value: 88.022
  - task:
      type: Clustering
    dataset:
      name: MTEB RedditClustering
      type: mteb/reddit-clustering
      config: default
      split: test
      revision: 24640382cdbf8abc73003fb0fa6d111a705499eb
    metrics:
    - type: v_measure
      value: 55.719165988934385
  - task:
      type: Clustering
    dataset:
      name: MTEB RedditClusteringP2P
      type: mteb/reddit-clustering-p2p
      config: default
      split: test
      revision: 282350215ef01743dc01b456c7f5241fa8937f16
    metrics:
    - type: v_measure
      value: 62.25390069273025
  - task:
      type: Retrieval
    dataset:
      name: MTEB SCIDOCS
      type: mteb/scidocs
      config: default
      split: test
      revision: None
    metrics:
    - type: ndcg_at_10
      value: 18.243000000000002
  - task:
      type: Retrieval
    dataset:
      name: MTEB SCIDOCS-PL
      type: clarin-knext/scidocs-pl
      config: default
      split: test
      revision: 45452b03f05560207ef19149545f168e596c9337
    metrics:
    - type: ndcg_at_10
      value: 14.219000000000001
  - task:
      type: PairClassification
    dataset:
      name: MTEB SICK-E-PL
      type: PL-MTEB/sicke-pl-pairclassification
      config: default
      split: test
      revision: None
    metrics:
    - type: cos_sim_ap
      value: 75.4022630307816
  - task:
      type: STS
    dataset:
      name: MTEB SICK-R
      type: mteb/sickr-sts
      config: default
      split: test
      revision: a6ea5a8cab320b040a23452cc28066d9beae2cee
    metrics:
    - type: cos_sim_spearman
      value: 79.34269390198548
  - task:
      type: STS
    dataset:
      name: MTEB SICK-R-PL
      type: PL-MTEB/sickr-pl-sts
      config: default
      split: test
      revision: None
    metrics:
    - type: cos_sim_spearman
      value: 74.0651660446132
  - task:
      type: STS
    dataset:
      name: MTEB SICKFr
      type: Lajavaness/SICK-fr
      config: default
      split: test
      revision: e077ab4cf4774a1e36d86d593b150422fafd8e8a
    metrics:
    - type: cos_sim_spearman
      value: 78.62693119733123
  - task:
      type: STS
    dataset:
      name: MTEB STS12
      type: mteb/sts12-sts
      config: default
      split: test
      revision: a0d554a64d88156834ff5ae9920b964011b16384
    metrics:
    - type: cos_sim_spearman
      value: 77.50660544631359
  - task:
      type: STS
    dataset:
      name: MTEB STS13
      type: mteb/sts13-sts
      config: default
      split: test
      revision: 7e90230a92c190f1bf69ae9002b8cea547a64cca
    metrics:
    - type: cos_sim_spearman
      value: 85.55415077723738
  - task:
      type: STS
    dataset:
      name: MTEB STS14
      type: mteb/sts14-sts
      config: default
      split: test
      revision: 6031580fec1f6af667f0bd2da0a551cf4f0b2375
    metrics:
    - type: cos_sim_spearman
      value: 81.67550814479077
  - task:
      type: STS
    dataset:
      name: MTEB STS15
      type: mteb/sts15-sts
      config: default
      split: test
      revision: ae752c7c21bf194d8b67fd573edf7ae58183cbe3
    metrics:
    - type: cos_sim_spearman
      value: 88.94601412322764
  - task:
      type: STS
    dataset:
      name: MTEB STS16
      type: mteb/sts16-sts
      config: default
      split: test
      revision: 4d8694f8f0e0100860b497b999b3dbed754a0513
    metrics:
    - type: cos_sim_spearman
      value: 84.33844259337481
  - task:
      type: STS
    dataset:
      name: MTEB STS17 (ko-ko)
      type: mteb/sts17-crosslingual-sts
      config: ko-ko
      split: test
      revision: af5e6fb845001ecf41f4c1e033ce921939a2a68d
    metrics:
    - type: cos_sim_spearman
      value: 81.58650681159105
  - task:
      type: STS
    dataset:
      name: MTEB STS17 (ar-ar)
      type: mteb/sts17-crosslingual-sts
      config: ar-ar
      split: test
      revision: af5e6fb845001ecf41f4c1e033ce921939a2a68d
    metrics:
    - type: cos_sim_spearman
      value: 78.82472265884256
  - task:
      type: STS
    dataset:
      name: MTEB STS17 (en-ar)
      type: mteb/sts17-crosslingual-sts
      config: en-ar
      split: test
      revision: af5e6fb845001ecf41f4c1e033ce921939a2a68d
    metrics:
    - type: cos_sim_spearman
      value: 76.43637938260397
  - task:
      type: STS
    dataset:
      name: MTEB STS17 (en-de)
      type: mteb/sts17-crosslingual-sts
      config: en-de
      split: test
      revision: af5e6fb845001ecf41f4c1e033ce921939a2a68d
    metrics:
    - type: cos_sim_spearman
      value: 84.71008299464059
  - task:
      type: STS
    dataset:
      name: MTEB STS17 (en-en)
      type: mteb/sts17-crosslingual-sts
      config: en-en
      split: test
      revision: af5e6fb845001ecf41f4c1e033ce921939a2a68d
    metrics:
    - type: cos_sim_spearman
      value: 88.88074713413747
  - task:
      type: STS
    dataset:
      name: MTEB STS17 (en-tr)
      type: mteb/sts17-crosslingual-sts
      config: en-tr
      split: test
      revision: af5e6fb845001ecf41f4c1e033ce921939a2a68d
    metrics:
    - type: cos_sim_spearman
      value: 76.36405640457285
  - task:
      type: STS
    dataset:
      name: MTEB STS17 (es-en)
      type: mteb/sts17-crosslingual-sts
      config: es-en
      split: test
      revision: af5e6fb845001ecf41f4c1e033ce921939a2a68d
    metrics:
    - type: cos_sim_spearman
      value: 83.84737910084762
  - task:
      type: STS
    dataset:
      name: MTEB STS17 (es-es)
      type: mteb/sts17-crosslingual-sts
      config: es-es
      split: test
      revision: af5e6fb845001ecf41f4c1e033ce921939a2a68d
    metrics:
    - type: cos_sim_spearman
      value: 87.03931621433031
  - task:
      type: STS
    dataset:
      name: MTEB STS17 (fr-en)
      type: mteb/sts17-crosslingual-sts
      config: fr-en
      split: test
      revision: af5e6fb845001ecf41f4c1e033ce921939a2a68d
    metrics:
    - type: cos_sim_spearman
      value: 84.43335591752246
  - task:
      type: STS
    dataset:
      name: MTEB STS17 (it-en)
      type: mteb/sts17-crosslingual-sts
      config: it-en
      split: test
      revision: af5e6fb845001ecf41f4c1e033ce921939a2a68d
    metrics:
    - type: cos_sim_spearman
      value: 83.85268648747021
  - task:
      type: STS
    dataset:
      name: MTEB STS17 (nl-en)
      type: mteb/sts17-crosslingual-sts
      config: nl-en
      split: test
      revision: af5e6fb845001ecf41f4c1e033ce921939a2a68d
    metrics:
    - type: cos_sim_spearman
      value: 82.45786516224341
  - task:
      type: STS
    dataset:
      name: MTEB STS22 (en)
      type: mteb/sts22-crosslingual-sts
      config: en
      split: test
      revision: eea2b4fe26a775864c896887d910b76a8098ad3f
    metrics:
    - type: cos_sim_spearman
      value: 67.20227303970304
  - task:
      type: STS
    dataset:
      name: MTEB STS22 (de)
      type: mteb/sts22-crosslingual-sts
      config: de
      split: test
      revision: eea2b4fe26a775864c896887d910b76a8098ad3f
    metrics:
    - type: cos_sim_spearman
      value: 60.892838305537126
  - task:
      type: STS
    dataset:
      name: MTEB STS22 (es)
      type: mteb/sts22-crosslingual-sts
      config: es
      split: test
      revision: eea2b4fe26a775864c896887d910b76a8098ad3f
    metrics:
    - type: cos_sim_spearman
      value: 72.01876318464508
  - task:
      type: STS
    dataset:
      name: MTEB STS22 (pl)
      type: mteb/sts22-crosslingual-sts
      config: pl
      split: test
      revision: eea2b4fe26a775864c896887d910b76a8098ad3f
    metrics:
    - type: cos_sim_spearman
      value: 42.3879320510127
  - task:
      type: STS
    dataset:
      name: MTEB STS22 (tr)
      type: mteb/sts22-crosslingual-sts
      config: tr
      split: test
      revision: eea2b4fe26a775864c896887d910b76a8098ad3f
    metrics:
    - type: cos_sim_spearman
      value: 65.54048784845729
  - task:
      type: STS
    dataset:
      name: MTEB STS22 (ar)
      type: mteb/sts22-crosslingual-sts
      config: ar
      split: test
      revision: eea2b4fe26a775864c896887d910b76a8098ad3f
    metrics:
    - type: cos_sim_spearman
      value: 58.55244068334867
  - task:
      type: STS
    dataset:
      name: MTEB STS22 (ru)
      type: mteb/sts22-crosslingual-sts
      config: ru
      split: test
      revision: eea2b4fe26a775864c896887d910b76a8098ad3f
    metrics:
    - type: cos_sim_spearman
      value: 66.48710288440624
  - task:
      type: STS
    dataset:
      name: MTEB STS22 (zh)
      type: mteb/sts22-crosslingual-sts
      config: zh
      split: test
      revision: eea2b4fe26a775864c896887d910b76a8098ad3f
    metrics:
    - type: cos_sim_spearman
      value: 66.585754901838
  - task:
      type: STS
    dataset:
      name: MTEB STS22 (fr)
      type: mteb/sts22-crosslingual-sts
      config: fr
      split: test
      revision: eea2b4fe26a775864c896887d910b76a8098ad3f
    metrics:
    - type: cos_sim_spearman
      value: 81.03001290557805
  - task:
      type: STS
    dataset:
      name: MTEB STS22 (de-en)
      type: mteb/sts22-crosslingual-sts
      config: de-en
      split: test
      revision: eea2b4fe26a775864c896887d910b76a8098ad3f
    metrics:
    - type: cos_sim_spearman
      value: 62.28001859884359
  - task:
      type: STS
    dataset:
      name: MTEB STS22 (es-en)
      type: mteb/sts22-crosslingual-sts
      config: es-en
      split: test
      revision: eea2b4fe26a775864c896887d910b76a8098ad3f
    metrics:
    - type: cos_sim_spearman
      value: 79.64106342105019
  - task:
      type: STS
    dataset:
      name: MTEB STS22 (it)
      type: mteb/sts22-crosslingual-sts
      config: it
      split: test
      revision: eea2b4fe26a775864c896887d910b76a8098ad3f
    metrics:
    - type: cos_sim_spearman
      value: 78.27915339361124
  - task:
      type: STS
    dataset:
      name: MTEB STS22 (pl-en)
      type: mteb/sts22-crosslingual-sts
      config: pl-en
      split: test
      revision: eea2b4fe26a775864c896887d910b76a8098ad3f
    metrics:
    - type: cos_sim_spearman
      value: 78.28574268257462
  - task:
      type: STS
    dataset:
      name: MTEB STS22 (zh-en)
      type: mteb/sts22-crosslingual-sts
      config: zh-en
      split: test
      revision: eea2b4fe26a775864c896887d910b76a8098ad3f
    metrics:
    - type: cos_sim_spearman
      value: 72.92658860751482
  - task:
      type: STS
    dataset:
      name: MTEB STS22 (es-it)
      type: mteb/sts22-crosslingual-sts
      config: es-it
      split: test
      revision: eea2b4fe26a775864c896887d910b76a8098ad3f
    metrics:
    - type: cos_sim_spearman
      value: 74.83418886368217
  - task:
      type: STS
    dataset:
      name: MTEB STS22 (de-fr)
      type: mteb/sts22-crosslingual-sts
      config: de-fr
      split: test
      revision: eea2b4fe26a775864c896887d910b76a8098ad3f
    metrics:
    - type: cos_sim_spearman
      value: 56.01064022625769
  - task:
      type: STS
    dataset:
      name: MTEB STS22 (de-pl)
      type: mteb/sts22-crosslingual-sts
      config: de-pl
      split: test
      revision: eea2b4fe26a775864c896887d910b76a8098ad3f
    metrics:
    - type: cos_sim_spearman
      value: 53.64332829635126
  - task:
      type: STS
    dataset:
      name: MTEB STS22 (fr-pl)
      type: mteb/sts22-crosslingual-sts
      config: fr-pl
      split: test
      revision: eea2b4fe26a775864c896887d910b76a8098ad3f
    metrics:
    - type: cos_sim_spearman
      value: 73.24670207647144
  - task:
      type: STS
    dataset:
      name: MTEB STSB
      type: C-MTEB/STSB
      config: default
      split: test
      revision: 0cde68302b3541bb8b3c340dc0644b0b745b3dc0
    metrics:
    - type: cos_sim_spearman
      value: 80.7157790971544
  - task:
      type: STS
    dataset:
      name: MTEB STSBenchmark
      type: mteb/stsbenchmark-sts
      config: default
      split: test
      revision: b0fddb56ed78048fa8b90373c8a3cfc37b684831
    metrics:
    - type: cos_sim_spearman
      value: 86.45763616928973
  - task:
      type: STS
    dataset:
      name: MTEB STSBenchmarkMultilingualSTS (fr)
      type: stsb_multi_mt
      config: fr
      split: test
      revision: 93d57ef91790589e3ce9c365164337a8a78b7632
    metrics:
    - type: cos_sim_spearman
      value: 84.4335500335282
  - task:
      type: Reranking
    dataset:
      name: MTEB SciDocsRR
      type: mteb/scidocs-reranking
      config: default
      split: test
      revision: d3c5e1fc0b855ab6097bf1cda04dd73947d7caab
    metrics:
    - type: map
      value: 84.15276484499303
  - task:
      type: Retrieval
    dataset:
      name: MTEB SciFact
      type: mteb/scifact
      config: default
      split: test
      revision: 0228b52cf27578f30900b9e5271d331663a030d7
    metrics:
    - type: ndcg_at_10
      value: 73.433
  - task:
      type: Retrieval
    dataset:
      name: MTEB SciFact-PL
      type: clarin-knext/scifact-pl
      config: default
      split: test
      revision: 47932a35f045ef8ed01ba82bf9ff67f6e109207e
    metrics:
    - type: ndcg_at_10
      value: 58.919999999999995
  - task:
      type: PairClassification
    dataset:
      name: MTEB SprintDuplicateQuestions
      type: mteb/sprintduplicatequestions-pairclassification
      config: default
      split: test
      revision: d66bd1f72af766a5cc4b0ca5e00c162f89e8cc46
    metrics:
    - type: cos_sim_ap
      value: 95.40564890916419
  - task:
      type: Clustering
    dataset:
      name: MTEB StackExchangeClustering
      type: mteb/stackexchange-clustering
      config: default
      split: test
      revision: 6cbc1f7b2bc0622f2e39d2c77fa502909748c259
    metrics:
    - type: v_measure
      value: 63.41856697730145
  - task:
      type: Clustering
    dataset:
      name: MTEB StackExchangeClusteringP2P
      type: mteb/stackexchange-clustering-p2p
      config: default
      split: test
      revision: 815ca46b2622cec33ccafc3735d572c266efdb44
    metrics:
    - type: v_measure
      value: 31.709285904909112
  - task:
      type: Reranking
    dataset:
      name: MTEB StackOverflowDupQuestions
      type: mteb/stackoverflowdupquestions-reranking
      config: default
      split: test
      revision: e185fbe320c72810689fc5848eb6114e1ef5ec69
    metrics:
    - type: map
      value: 52.09341030060322
  - task:
      type: Summarization
    dataset:
      name: MTEB SummEval
      type: mteb/summeval
      config: default
      split: test
      revision: cda12ad7615edc362dbf25a00fdd61d3b1eaf93c
    metrics:
    - type: cos_sim_spearman
      value: 30.58262517835034
  - task:
      type: Summarization
    dataset:
      name: MTEB SummEvalFr
      type: lyon-nlp/summarization-summeval-fr-p2p
      config: default
      split: test
      revision: b385812de6a9577b6f4d0f88c6a6e35395a94054
    metrics:
    - type: cos_sim_spearman
      value: 29.744542072951358
  - task:
      type: Reranking
    dataset:
      name: MTEB SyntecReranking
      type: lyon-nlp/mteb-fr-reranking-syntec-s2p
      config: default
      split: test
      revision: b205c5084a0934ce8af14338bf03feb19499c84d
    metrics:
    - type: map
      value: 88.03333333333333
  - task:
      type: Retrieval
    dataset:
      name: MTEB SyntecRetrieval
      type: lyon-nlp/mteb-fr-retrieval-syntec-s2p
      config: default
      split: test
      revision: 77f7e271bf4a92b24fce5119f3486b583ca016ff
    metrics:
    - type: ndcg_at_10
      value: 83.043
  - task:
      type: Reranking
    dataset:
      name: MTEB T2Reranking
      type: C-MTEB/T2Reranking
      config: default
      split: dev
      revision: 76631901a18387f85eaa53e5450019b87ad58ef9
    metrics:
    - type: map
      value: 67.08577894804324
  - task:
      type: Retrieval
    dataset:
      name: MTEB T2Retrieval
      type: C-MTEB/T2Retrieval
      config: default
      split: dev
      revision: 8731a845f1bf500a4f111cf1070785c793d10e64
    metrics:
    - type: ndcg_at_10
      value: 84.718
  - task:
      type: Classification
    dataset:
      name: MTEB TNews
      type: C-MTEB/TNews-classification
      config: default
      split: validation
      revision: 317f262bf1e6126357bbe89e875451e4b0938fe4
    metrics:
    - type: accuracy
      value: 48.726
  - task:
      type: Retrieval
    dataset:
      name: MTEB TRECCOVID
      type: mteb/trec-covid
      config: default
      split: test
      revision: None
    metrics:
    - type: ndcg_at_10
      value: 57.56
  - task:
      type: Retrieval
    dataset:
      name: MTEB TRECCOVID-PL
      type: clarin-knext/trec-covid-pl
      config: default
      split: test
      revision: 81bcb408f33366c2a20ac54adafad1ae7e877fdd
    metrics:
    - type: ndcg_at_10
      value: 59.355999999999995
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (sqi-eng)
      type: mteb/tatoeba-bitext-mining
      config: sqi-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 82.765
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (fry-eng)
      type: mteb/tatoeba-bitext-mining
      config: fry-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 73.69942196531792
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (kur-eng)
      type: mteb/tatoeba-bitext-mining
      config: kur-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 32.86585365853657
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (tur-eng)
      type: mteb/tatoeba-bitext-mining
      config: tur-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 95.81666666666666
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (deu-eng)
      type: mteb/tatoeba-bitext-mining
      config: deu-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 97.75
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (nld-eng)
      type: mteb/tatoeba-bitext-mining
      config: nld-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 93.78333333333335
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (ron-eng)
      type: mteb/tatoeba-bitext-mining
      config: ron-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 90.72333333333333
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (ang-eng)
      type: mteb/tatoeba-bitext-mining
      config: ang-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 42.45202558635395
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (ido-eng)
      type: mteb/tatoeba-bitext-mining
      config: ido-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 77.59238095238095
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (jav-eng)
      type: mteb/tatoeba-bitext-mining
      config: jav-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 35.69686411149825
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (isl-eng)
      type: mteb/tatoeba-bitext-mining
      config: isl-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 82.59333333333333
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (slv-eng)
      type: mteb/tatoeba-bitext-mining
      config: slv-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 84.1456922987907
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (cym-eng)
      type: mteb/tatoeba-bitext-mining
      config: cym-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 52.47462133594857
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (kaz-eng)
      type: mteb/tatoeba-bitext-mining
      config: kaz-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 67.62965440356746
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (est-eng)
      type: mteb/tatoeba-bitext-mining
      config: est-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 79.48412698412699
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (heb-eng)
      type: mteb/tatoeba-bitext-mining
      config: heb-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 75.85
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (gla-eng)
      type: mteb/tatoeba-bitext-mining
      config: gla-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 27.32600866497127
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (mar-eng)
      type: mteb/tatoeba-bitext-mining
      config: mar-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 84.38
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (lat-eng)
      type: mteb/tatoeba-bitext-mining
      config: lat-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 42.98888712165028
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (bel-eng)
      type: mteb/tatoeba-bitext-mining
      config: bel-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 85.55690476190476
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (pms-eng)
      type: mteb/tatoeba-bitext-mining
      config: pms-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 46.68466031323174
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (gle-eng)
      type: mteb/tatoeba-bitext-mining
      config: gle-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 32.73071428571428
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (pes-eng)
      type: mteb/tatoeba-bitext-mining
      config: pes-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 88.26333333333334
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (nob-eng)
      type: mteb/tatoeba-bitext-mining
      config: nob-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 96.61666666666666
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (bul-eng)
      type: mteb/tatoeba-bitext-mining
      config: bul-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 91.30666666666666
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (cbk-eng)
      type: mteb/tatoeba-bitext-mining
      config: cbk-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 70.03714285714285
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (hun-eng)
      type: mteb/tatoeba-bitext-mining
      config: hun-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 89.09
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (uig-eng)
      type: mteb/tatoeba-bitext-mining
      config: uig-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 59.570476190476185
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (rus-eng)
      type: mteb/tatoeba-bitext-mining
      config: rus-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 92.9
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (spa-eng)
      type: mteb/tatoeba-bitext-mining
      config: spa-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 97.68333333333334
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (hye-eng)
      type: mteb/tatoeba-bitext-mining
      config: hye-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 80.40880503144653
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (tel-eng)
      type: mteb/tatoeba-bitext-mining
      config: tel-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 89.7008547008547
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (afr-eng)
      type: mteb/tatoeba-bitext-mining
      config: afr-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 81.84833333333333
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (mon-eng)
      type: mteb/tatoeba-bitext-mining
      config: mon-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 71.69696969696969
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (arz-eng)
      type: mteb/tatoeba-bitext-mining
      config: arz-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 55.76985790822269
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (hrv-eng)
      type: mteb/tatoeba-bitext-mining
      config: hrv-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 91.66666666666666
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (nov-eng)
      type: mteb/tatoeba-bitext-mining
      config: nov-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 68.36668519547896
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (gsw-eng)
      type: mteb/tatoeba-bitext-mining
      config: gsw-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 36.73992673992674
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (nds-eng)
      type: mteb/tatoeba-bitext-mining
      config: nds-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 63.420952380952365
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (ukr-eng)
      type: mteb/tatoeba-bitext-mining
      config: ukr-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 91.28999999999999
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (uzb-eng)
      type: mteb/tatoeba-bitext-mining
      config: uzb-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 40.95392490046146
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (lit-eng)
      type: mteb/tatoeba-bitext-mining
      config: lit-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 77.58936507936508
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (ina-eng)
      type: mteb/tatoeba-bitext-mining
      config: ina-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 91.28999999999999
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (lfn-eng)
      type: mteb/tatoeba-bitext-mining
      config: lfn-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 63.563650793650794
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (zsm-eng)
      type: mteb/tatoeba-bitext-mining
      config: zsm-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 94.35
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (ita-eng)
      type: mteb/tatoeba-bitext-mining
      config: ita-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 91.43
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (cmn-eng)
      type: mteb/tatoeba-bitext-mining
      config: cmn-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 95.73333333333332
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (lvs-eng)
      type: mteb/tatoeba-bitext-mining
      config: lvs-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 79.38666666666667
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (glg-eng)
      type: mteb/tatoeba-bitext-mining
      config: glg-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 89.64
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (ceb-eng)
      type: mteb/tatoeba-bitext-mining
      config: ceb-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 21.257184628237262
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (bre-eng)
      type: mteb/tatoeba-bitext-mining
      config: bre-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 13.592316017316017
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (ben-eng)
      type: mteb/tatoeba-bitext-mining
      config: ben-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 73.22666666666666
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (swg-eng)
      type: mteb/tatoeba-bitext-mining
      config: swg-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 51.711309523809526
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (arq-eng)
      type: mteb/tatoeba-bitext-mining
      config: arq-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 24.98790634904795
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (kab-eng)
      type: mteb/tatoeba-bitext-mining
      config: kab-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 17.19218192918193
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (fra-eng)
      type: mteb/tatoeba-bitext-mining
      config: fra-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 93.26666666666667
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (por-eng)
      type: mteb/tatoeba-bitext-mining
      config: por-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 94.57333333333334
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (tat-eng)
      type: mteb/tatoeba-bitext-mining
      config: tat-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 42.35127206127206
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (oci-eng)
      type: mteb/tatoeba-bitext-mining
      config: oci-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 51.12318903318903
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (pol-eng)
      type: mteb/tatoeba-bitext-mining
      config: pol-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 94.89999999999999
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (war-eng)
      type: mteb/tatoeba-bitext-mining
      config: war-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 23.856320290390055
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (aze-eng)
      type: mteb/tatoeba-bitext-mining
      config: aze-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 79.52833333333334
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (vie-eng)
      type: mteb/tatoeba-bitext-mining
      config: vie-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 95.93333333333334
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (nno-eng)
      type: mteb/tatoeba-bitext-mining
      config: nno-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 90.75333333333333
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (cha-eng)
      type: mteb/tatoeba-bitext-mining
      config: cha-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 30.802919708029197
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (mhr-eng)
      type: mteb/tatoeba-bitext-mining
      config: mhr-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 15.984076294076294
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (dan-eng)
      type: mteb/tatoeba-bitext-mining
      config: dan-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 91.82666666666667
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (ell-eng)
      type: mteb/tatoeba-bitext-mining
      config: ell-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 91.9
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (amh-eng)
      type: mteb/tatoeba-bitext-mining
      config: amh-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 76.36054421768706
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (pam-eng)
      type: mteb/tatoeba-bitext-mining
      config: pam-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 9.232711399711398
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (hsb-eng)
      type: mteb/tatoeba-bitext-mining
      config: hsb-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 45.640803181175855
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (srp-eng)
      type: mteb/tatoeba-bitext-mining
      config: srp-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 86.29
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (epo-eng)
      type: mteb/tatoeba-bitext-mining
      config: epo-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 88.90833333333332
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (kzj-eng)
      type: mteb/tatoeba-bitext-mining
      config: kzj-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 11.11880248978075
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (awa-eng)
      type: mteb/tatoeba-bitext-mining
      config: awa-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 48.45839345839346
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (fao-eng)
      type: mteb/tatoeba-bitext-mining
      config: fao-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 65.68157033805888
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (mal-eng)
      type: mteb/tatoeba-bitext-mining
      config: mal-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 94.63852498786997
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (ile-eng)
      type: mteb/tatoeba-bitext-mining
      config: ile-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 81.67904761904761
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (bos-eng)
      type: mteb/tatoeba-bitext-mining
      config: bos-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 89.35969868173258
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (cor-eng)
      type: mteb/tatoeba-bitext-mining
      config: cor-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 5.957229437229437
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (cat-eng)
      type: mteb/tatoeba-bitext-mining
      config: cat-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 91.50333333333333
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (eus-eng)
      type: mteb/tatoeba-bitext-mining
      config: eus-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 63.75498778998778
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (yue-eng)
      type: mteb/tatoeba-bitext-mining
      config: yue-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 82.99190476190476
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (swe-eng)
      type: mteb/tatoeba-bitext-mining
      config: swe-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 92.95
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (dtp-eng)
      type: mteb/tatoeba-bitext-mining
      config: dtp-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 9.054042624042623
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (kat-eng)
      type: mteb/tatoeba-bitext-mining
      config: kat-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 72.77064981488574
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (jpn-eng)
      type: mteb/tatoeba-bitext-mining
      config: jpn-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 93.14
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (csb-eng)
      type: mteb/tatoeba-bitext-mining
      config: csb-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 29.976786498525627
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (xho-eng)
      type: mteb/tatoeba-bitext-mining
      config: xho-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 67.6525821596244
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (orv-eng)
      type: mteb/tatoeba-bitext-mining
      config: orv-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 33.12964812964813
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (ind-eng)
      type: mteb/tatoeba-bitext-mining
      config: ind-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 92.30666666666666
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (tuk-eng)
      type: mteb/tatoeba-bitext-mining
      config: tuk-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 34.36077879427633
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (max-eng)
      type: mteb/tatoeba-bitext-mining
      config: max-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 52.571845212690285
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (swh-eng)
      type: mteb/tatoeba-bitext-mining
      config: swh-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 58.13107263107262
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (hin-eng)
      type: mteb/tatoeba-bitext-mining
      config: hin-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 93.33333333333333
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (dsb-eng)
      type: mteb/tatoeba-bitext-mining
      config: dsb-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 42.87370133925458
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (ber-eng)
      type: mteb/tatoeba-bitext-mining
      config: ber-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 20.394327616827614
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (tam-eng)
      type: mteb/tatoeba-bitext-mining
      config: tam-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 84.29967426710098
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (slk-eng)
      type: mteb/tatoeba-bitext-mining
      config: slk-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 88.80666666666667
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (tgl-eng)
      type: mteb/tatoeba-bitext-mining
      config: tgl-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 67.23062271062273
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (ast-eng)
      type: mteb/tatoeba-bitext-mining
      config: ast-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 78.08398950131233
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (mkd-eng)
      type: mteb/tatoeba-bitext-mining
      config: mkd-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 77.85166666666666
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (khm-eng)
      type: mteb/tatoeba-bitext-mining
      config: khm-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 67.63004001231148
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (ces-eng)
      type: mteb/tatoeba-bitext-mining
      config: ces-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 89.77000000000001
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (tzl-eng)
      type: mteb/tatoeba-bitext-mining
      config: tzl-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 40.2654503616042
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (urd-eng)
      type: mteb/tatoeba-bitext-mining
      config: urd-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 83.90333333333334
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (ara-eng)
      type: mteb/tatoeba-bitext-mining
      config: ara-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 77.80666666666666
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (kor-eng)
      type: mteb/tatoeba-bitext-mining
      config: kor-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 84.08
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (yid-eng)
      type: mteb/tatoeba-bitext-mining
      config: yid-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 60.43098607367475
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (fin-eng)
      type: mteb/tatoeba-bitext-mining
      config: fin-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 88.19333333333333
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (tha-eng)
      type: mteb/tatoeba-bitext-mining
      config: tha-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 90.55352798053529
  - task:
      type: BitextMining
    dataset:
      name: MTEB Tatoeba (wuu-eng)
      type: mteb/tatoeba-bitext-mining
      config: wuu-eng
      split: test
      revision: 9080400076fbadbb4c4dcb136ff4eddc40b42553
    metrics:
    - type: f1
      value: 88.44999999999999
  - task:
      type: Clustering
    dataset:
      name: MTEB ThuNewsClusteringP2P
      type: C-MTEB/ThuNewsClusteringP2P
      config: default
      split: test
      revision: 5798586b105c0434e4f0fe5e767abe619442cf93
    metrics:
    - type: v_measure
      value: 57.25416429643288
  - task:
      type: Clustering
    dataset:
      name: MTEB ThuNewsClusteringS2S
      type: C-MTEB/ThuNewsClusteringS2S
      config: default
      split: test
      revision: 8a8b2caeda43f39e13c4bc5bea0f8a667896e10d
    metrics:
    - type: v_measure
      value: 56.616646560243524
  - task:
      type: Retrieval
    dataset:
      name: MTEB Touche2020
      type: mteb/touche2020
      config: default
      split: test
      revision: a34f9a33db75fa0cbb21bb5cfc3dae8dc8bec93f
    metrics:
    - type: ndcg_at_10
      value: 22.819
  - task:
      type: Classification
    dataset:
      name: MTEB ToxicConversationsClassification
      type: mteb/toxic_conversations_50k
      config: default
      split: test
      revision: d7c0de2777da35d6aae2200a62c6e0e5af397c4c
    metrics:
    - type: accuracy
      value: 71.02579999999999
  - task:
      type: Classification
    dataset:
      name: MTEB TweetSentimentExtractionClassification
      type: mteb/tweet_sentiment_extraction
      config: default
      split: test
      revision: d604517c81ca91fe16a244d1248fc021f9ecee7a
    metrics:
    - type: accuracy
      value: 57.60045274476514
  - task:
      type: Clustering
    dataset:
      name: MTEB TwentyNewsgroupsClustering
      type: mteb/twentynewsgroups-clustering
      config: default
      split: test
      revision: 6125ec4e24fa026cec8a478383ee943acfbd5449
    metrics:
    - type: v_measure
      value: 50.346666699466205
  - task:
      type: PairClassification
    dataset:
      name: MTEB TwitterSemEval2015
      type: mteb/twittersemeval2015-pairclassification
      config: default
      split: test
      revision: 70970daeab8776df92f5ea462b6173c0b46fd2d1
    metrics:
    - type: cos_sim_ap
      value: 71.88199004440489
  - task:
      type: PairClassification
    dataset:
      name: MTEB TwitterURLCorpus
      type: mteb/twitterurlcorpus-pairclassification
      config: default
      split: test
      revision: 8b6510b0b1fa4e4c4f879467980e9be563ec1cdf
    metrics:
    - type: cos_sim_ap
      value: 85.41587779677383
  - task:
      type: Retrieval
    dataset:
      name: MTEB VideoRetrieval
      type: C-MTEB/VideoRetrieval
      config: default
      split: dev
      revision: 58c2597a5943a2ba48f4668c3b90d796283c5639
    metrics:
    - type: ndcg_at_10
      value: 72.792
  - task:
      type: Classification
    dataset:
      name: MTEB Waimai
      type: C-MTEB/waimai-classification
      config: default
      split: test
      revision: 339287def212450dcaa9df8c22bf93e9980c7023
    metrics:
    - type: accuracy
      value: 82.58000000000001
  - task:
      type: Retrieval
    dataset:
      name: MTEB XPQARetrieval (fr)
      type: jinaai/xpqa
      config: fr
      split: test
      revision: c99d599f0a6ab9b85b065da6f9d94f9cf731679f
    metrics:
    - type: ndcg_at_10
      value: 67.327
---

## gte-multilingual-base

The **gte-multilingual-base** model is the latest in the [GTE](https://huggingface.co/collections/Alibaba-NLP/gte-models-6680f0b13f885cb431e6d469) (General Text Embedding) family of models, featuring several key attributes:

- **High Performance**: Achieves state-of-the-art (SOTA) results in multilingual retrieval tasks and multi-task representation model evaluations when compared to models of similar size.
- **Training Architecture**: Trained using an encoder-only transformers architecture, resulting in a smaller model size. Unlike previous models based on decode-only LLM architecture (e.g., gte-qwen2-1.5b-instruct), this model has lower hardware requirements for inference, offering a 10x increase in inference speed.
- **Long Context**: Supports text lengths up to **8192** tokens.
- **Multilingual Capability**: Supports over **70** languages.
- **Elastic Dense Embedding**: Support elastic output dense representation while maintaining the effectiveness of downstream tasks, which significantly reduces storage costs and improves execution efficiency.
- **Sparse Vectors**: In addition to dense representations, it can also generate sparse vectors.


**Paper**: [mGTE: Generalized Long-Context Text Representation and Reranking Models for Multilingual Text Retrieval](https://arxiv.org/pdf/2407.19669)

## Model Information
- Model Size: 305M
- Embedding Dimension: 768
- Max Input Tokens: 8192


## Usage 

- **It is recommended to install xformers and enable unpadding for acceleration,
refer to [enable-unpadding-and-xformers](https://huggingface.co/Alibaba-NLP/new-impl#recommendation-enable-unpadding-and-acceleration-with-xformers).**
- **How to use it offline: [new-impl/discussions/2](https://huggingface.co/Alibaba-NLP/new-impl/discussions/2#662b08d04d8c3d0a09c88fa3)**
- **How to use with [TEI](https://github.com/huggingface/text-embeddings-inference): [refs/pr/7](https://huggingface.co/Alibaba-NLP/gte-multilingual-base/discussions/7#66bfb82ea03b764ca92a2221)**



### Get Dense Embeddings with Transformers
```python
# Requires transformers>=4.36.0

import torch.nn.functional as F
from transformers import AutoModel, AutoTokenizer

input_texts = [
    "what is the capital of China?",
    "how to implement quick sort in python?",
    "北京",
    "快排算法介绍"
]

model_name_or_path = 'Alibaba-NLP/gte-multilingual-base'
tokenizer = AutoTokenizer.from_pretrained(model_name_or_path)
model = AutoModel.from_pretrained(model_name_or_path, trust_remote_code=True)

# Tokenize the input texts
batch_dict = tokenizer(input_texts, max_length=8192, padding=True, truncation=True, return_tensors='pt')

outputs = model(**batch_dict)

dimension=768 # The output dimension of the output embedding, should be in [128, 768]
embeddings = outputs.last_hidden_state[:, 0][:dimension]

embeddings = F.normalize(embeddings, p=2, dim=1)
scores = (embeddings[:1] @ embeddings[1:].T) * 100
print(scores.tolist())

# [[0.3016996383666992, 0.7503870129585266, 0.3203084468841553]]
```

### Use with sentence-transformers
```python
# Requires sentence-transformers>=3.0.0

from sentence_transformers import SentenceTransformer

input_texts = [
    "what is the capital of China?",
    "how to implement quick sort in python?",
    "北京",
    "快排算法介绍"
]

model_name_or_path="Alibaba-NLP/gte-multilingual-base"
model = SentenceTransformer(model_name_or_path, trust_remote_code=True)
embeddings = model.encode(input_texts, normalize_embeddings=True) # embeddings.shape (4, 768)

# sim scores
scores = model.similarity(embeddings[:1], embeddings[1:])

print(scores.tolist())
# [[0.301699697971344, 0.7503870129585266, 0.32030850648880005]]
```

### Use with infinity

Usage via docker and [infinity](https://github.com/michaelfeil/infinity), MIT Licensed.
```
docker run --gpus all -v $PWD/data:/app/.cache -p "7997":"7997" \
michaelf34/infinity:0.0.69 \
v2 --model-id Alibaba-NLP/gte-multilingual-base --revision "main" --dtype float16 --batch-size 32 --device cuda --engine torch --port 7997
```

### Use with Text Embeddings Inference (TEI)

Usage via Docker and [Text Embeddings Inference (TEI)](https://github.com/huggingface/text-embeddings-inference):

- CPU:

```bash
docker run --platform linux/amd64 \
  -p 8080:80 \
  -v $PWD/data:/data \
  --pull always \
  ghcr.io/huggingface/text-embeddings-inference:cpu-1.7 \
  --model-id Alibaba-NLP/gte-multilingual-base \
  --dtype float16
```

- GPU:

```
docker run --gpus all \
  -p 8080:80 \
  -v $PWD/data:/data \
  --pull always \
  ghcr.io/huggingface/text-embeddings-inference:1.7 \
  --model-id Alibaba-NLP/gte-multilingual-base \
  --dtype float16
```

Then you can send requests to the deployed API via the OpenAI-compatible `v1/embeddings` route (more information about the [OpenAI Embeddings API](https://platform.openai.com/docs/api-reference/embeddings)):

```bash
curl https://0.0.0.0:8080/v1/embeddings \
  -H "Content-Type: application/json" \
  -d '{
    "input": [
      "what is the capital of China?",
      "how to implement quick sort in python?",
      "北京",
      "快排算法介绍"
    ],
    "model": "Alibaba-NLP/gte-multilingual-base",
    "encoding_format": "float"
  }'
```

### Use with custom code to get dense embeddings and sparse token weights
```python
# You can find the script gte_embedding.py in https://huggingface.co/Alibaba-NLP/gte-multilingual-base/blob/main/scripts/gte_embedding.py

from gte_embedding import GTEEmbeddidng

model_name_or_path = 'Alibaba-NLP/gte-multilingual-base'
model = GTEEmbeddidng(model_name_or_path)
query = "中国的首都在哪儿"

docs = [
    "what is the capital of China?",
    "how to implement quick sort in python?",
    "北京",
    "快排算法介绍"
]

embs = model.encode(docs, return_dense=True,return_sparse=True)
print('dense_embeddings vecs', embs['dense_embeddings'])
print('token_weights', embs['token_weights'])
pairs = [(query, doc) for doc in docs]
dense_scores = model.compute_scores(pairs, dense_weight=1.0, sparse_weight=0.0)
sparse_scores = model.compute_scores(pairs, dense_weight=0.0, sparse_weight=1.0)
hybrid_scores = model.compute_scores(pairs, dense_weight=1.0, sparse_weight=0.3)

print('dense_scores', dense_scores)
print('sparse_scores', sparse_scores)
print('hybrid_scores', hybrid_scores)

# dense_scores [0.85302734375, 0.257568359375, 0.76953125, 0.325439453125]
# sparse_scores [0.0, 0.0, 4.600879669189453, 1.570279598236084]
# hybrid_scores [0.85302734375, 0.257568359375, 2.1497951507568356, 0.7965233325958252]

```

## Evaluation

We validated the performance of the **gte-multilingual-base** model on multiple downstream tasks, including multilingual retrieval, cross-lingual retrieval, long text retrieval, and general text representation evaluation on the [MTEB Leaderboard](https://huggingface.co/spaces/mteb/leaderboard), among others.

### Retrieval Task

Retrieval results on [MIRACL](https://arxiv.org/abs/2210.09984) and [MLDR](https://arxiv.org/abs/2402.03216) (multilingual), [MKQA](https://arxiv.org/abs/2007.15207) (crosslingual), [BEIR](https://arxiv.org/abs/2104.08663) and [LoCo](https://arxiv.org/abs/2402.07440) (English).

![image](./images/mgte-retrieval.png)

- Detail results on [MLDR](https://arxiv.org/abs/2402.03216)

![image](./images/mgte-retrieval.png)

- Detail results on [LoCo](https://arxiv.org/abs/2402.07440)

### MTEB 

Results on MTEB English, Chinese, French, Polish

![image](./images/mgte-mteb.png)

**More detailed experimental results can be found in the [paper](https://arxiv.org/pdf/2407.19669)**.


## Cloud API Services

In addition to the open-source [GTE](https://huggingface.co/collections/Alibaba-NLP/gte-models-6680f0b13f885cb431e6d469) series models, GTE series models are also available as commercial API services on Alibaba Cloud.

- [Embedding Models](https://help.aliyun.com/zh/model-studio/developer-reference/general-text-embedding/): Three versions of the text embedding models are available: text-embedding-v1/v2/v3, with v3 being the latest API service.
- [ReRank Models](https://help.aliyun.com/zh/model-studio/developer-reference/general-text-sorting-model/): The gte-rerank model service is available.

Note that the models behind the commercial APIs are not entirely identical to the open-source models.

## Citation
If you find our paper or models helpful, please consider cite:

```
@inproceedings{zhang2024mgte,
  title={mGTE: Generalized Long-Context Text Representation and Reranking Models for Multilingual Text Retrieval},
  author={Zhang, Xin and Zhang, Yanzhao and Long, Dingkun and Xie, Wen and Dai, Ziqi and Tang, Jialong and Lin, Huan and Yang, Baosong and Xie, Pengjun and Huang, Fei and others},
  booktitle={Proceedings of the 2024 Conference on Empirical Methods in Natural Language Processing: Industry Track},
  pages={1393--1412},
  year={2024}
}
```