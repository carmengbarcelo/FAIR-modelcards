black-forest-labs/FLUX.1-Redux-dev
---
language:
- en
license: other
license_name: flux-1-dev-non-commercial-license
license_link: LICENSE.md
extra_gated_prompt: By clicking "Agree", you agree to the [FluxDev Non-Commercial
  License Agreement](https://huggingface.co/black-forest-labs/FLUX.1-Depth-dev/blob/main/LICENSE.md)
  and acknowledge the [Acceptable Use Policy](https://huggingface.co/black-forest-labs/FLUX.1-Depth-dev/blob/main/POLICY.md).
tags:
- image-generation
- flux
- diffusion-single-file
---

![image/png](https://huggingface.co/black-forest-labs/FLUX.1-Redux-dev/resolve/main/redux.png)

FLUX.1 Redux [dev] is an adapter for all FLUX.1 base models for image variation generation. 
Given an input image, FLUX.1 Redux can reproduce the image with slight variation, allowing to refine a given image.
It naturally integrates into more complex workflows unlocking image restyling. 
Restyling via text is also available through our API by providing an image plus a language prompt. 
For more information, please read our [blog post](https://blackforestlabs.ai/flux-1-tools/). 



# Usage
We provide a reference implementation of `FLUX.1 Redux [dev]`, as well as sampling code, in a dedicated [github repository](https://github.com/black-forest-labs/flux).

## API Endpoints
`FLUX.1 Redux [pro]` is available in our API [bfl.ml](https://docs.bfl.ml/). In addition to the `[dev]` adapter, the API endpoint allows users to modify an image given a textual description.
The feature is supported in our latest model FLUX1.1 [pro] Ultra, allowing for combining input images and text prompts to create high-quality 4-megapixel outputs with flexible aspect ratios.


![image/png](https://cdn-uploads.huggingface.co/production/uploads/64510d6304397681bcf9725b/P123igomKjAkmitOzot8T.png)

## Diffusers

To use `FLUX.1 Redux [pro]` with the 🧨 diffusers python library, first install or upgrade diffusers

```shell
pip install -U diffusers
```

Then you can use `FluxPriorReduxPipeline` along with `FluxPipeline` to generate images from images.

```python
import torch
from diffusers import FluxPriorReduxPipeline, FluxPipeline
from diffusers.utils import load_image

pipe_prior_redux = FluxPriorReduxPipeline.from_pretrained("black-forest-labs/FLUX.1-Redux-dev", torch_dtype=torch.bfloat16).to("cuda")
pipe = FluxPipeline.from_pretrained(
    "black-forest-labs/FLUX.1-dev" , 
    text_encoder=None,
    text_encoder_2=None,
    torch_dtype=torch.bfloat16
).to("cuda")

image = load_image("https://huggingface.co/datasets/huggingface/documentation-images/resolve/main/robot.png")
pipe_prior_output = pipe_prior_redux(image)
images = pipe(
    guidance_scale=2.5,
    num_inference_steps=50,
    generator=torch.Generator("cpu").manual_seed(0),
    **pipe_prior_output,
).images
images[0].save("flux-dev-redux.png")
```

To learn more check out the [diffusers](https://huggingface.co/docs/diffusers/main/en/api/pipelines/flux) documentation

---

# Limitations
- This model is not intended or able to provide factual information.
- As a statistical model this checkpoint might amplify existing societal biases.
- The model may fail to generate output that matches the prompts.
- Outputs are heavily influenced by the input image.

# Out-of-Scope Use
The model and its derivatives may not be used

- In any way that violates any applicable national, federal, state, local or international law or regulation.
- For the purpose of exploiting, harming or attempting to exploit or harm minors in any way; including but not limited to the solicitation, creation, acquisition, or dissemination of child exploitative content.
- To generate or disseminate verifiably false information and/or content with the purpose of harming others.
- To generate or disseminate personal identifiable information that can be used to harm an individual.
- To harass, abuse, threaten, stalk, or bully individuals or groups of individuals.
- To create non-consensual nudity or illegal pornographic content.
- For fully automated decision making that adversely impacts an individual's legal rights or otherwise creates or modifies a binding, enforceable obligation.
- Generating or facilitating large-scale disinformation campaigns.

# License
This model falls under the [`FLUX.1 [dev]` Non-Commercial License](https://huggingface.co/black-forest-labs/FLUX.1-Depth-dev/blob/main/LICENSE.md).