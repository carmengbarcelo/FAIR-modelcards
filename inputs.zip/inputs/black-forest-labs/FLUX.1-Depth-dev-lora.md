black-forest-labs/FLUX.1-Depth-dev-lora
---
language:
- en
license: other
license_name: flux-1-dev-non-commercial-license
license_link: LICENSE.md
extra_gated_prompt: By clicking "Agree", you agree to the [FluxDev Non-Commercial
  License Agreement](https://huggingface.co/black-forest-labs/FLUX.1-Depth-dev-lora/blob/main/LICENSE.md)
  and acknowledge the [Acceptable Use Policy](https://huggingface.co/black-forest-labs/FLUX.1-Depth-dev-lora/blob/main/POLICY.md).
tags:
- image-generation
- flux
- diffusion-single-file
---

![image/png](https://cdn-uploads.huggingface.co/production/uploads/61fc209cef99814f1705e934/kiqWwCOeLkzreoK0NqBVD.png)

`FLUX.1 Depth [dev] LoRA` is a LoRA extracted from [FLUX.1 Depth [dev]](https://huggingface.co/black-forest-labs/FLUX.1-Depth-dev), a 12 billion parameter rectified flow transformer capable of generating an image based on a text description while following the structure of a given input image.
For more information, please read our [blog post](https://blackforestlabs.ai/flux-1-tools/).
The LoRA is applicable to [FLUX.1 [dev]](https://huggingface.co/black-forest-labs/FLUX.1-dev).

# Key Features
1. Cutting-edge output quality.
2. It blends impressive prompt adherence with maintaining the structure of source images based on depth maps.
3. Trained using guidance distillation, making `FLUX.1 Depth [dev] LoRA` more efficient.
4. Open weights to drive new scientific research, and empower artists to develop innovative workflows.
5. Generated outputs can be used for personal, scientific, and commercial purposes as described in the [`FLUX.1 [dev]` Non-Commercial License](https://huggingface.co/black-forest-labs/FLUX.1-dev/blob/main/LICENSE.md).

# Usage
We provide a reference implementation of `FLUX.1 Depth [dev]`, as well as sampling code, in a dedicated [github repository](https://github.com/black-forest-labs/flux).
Developers and creatives looking to build on top of `FLUX.1 Depth [dev]` are encouraged to use this as a starting point.

## API Endpoints
`FLUX.1 Depth [pro]` is available in our API [bfl.ml](https://docs.bfl.ml/)

## Diffusers

To use FLUX.1-Depth-dev-lora with the 🧨 diffusers python library, first install or upgrade `diffusers`, `peft`, and `image_gen_aux`.

```bash
pip install -U git+https://github.com/huggingface/diffusers
pip install git+https://github.com/asomoza/image_gen_aux.git
pip install -U peft
```

Then you can use the `FluxControlPipeline` to run it:

```py
import torch
from diffusers import FluxControlPipeline, FluxTransformer2DModel
from diffusers.utils import load_image
from image_gen_aux import DepthPreprocessor

pipe = FluxControlPipeline.from_pretrained("black-forest-labs/FLUX.1-dev", torch_dtype=torch.bfloat16).to("cuda")
pipe.load_lora_weights("black-forest-labs/FLUX.1-Depth-dev-lora", adapter_name="depth")
pipe.set_adapters("depth", 0.85)

prompt = "A robot made of exotic candies and chocolates of different kinds. The background is filled with confetti and celebratory gifts."
control_image = load_image("https://huggingface.co/datasets/huggingface/documentation-images/resolve/main/robot.png")

processor = DepthPreprocessor.from_pretrained("LiheYoung/depth-anything-large-hf")
control_image = processor(control_image)[0].convert("RGB")

image = pipe(
    prompt=prompt,
    control_image=control_image,
    height=1024,
    width=1024,
    num_inference_steps=30,
    guidance_scale=10.0,
    generator=torch.Generator().manual_seed(42),
).images[0]
image.save("output.png")
```

To learn more, check out the [diffusers documentation](https://huggingface.co/docs/diffusers/main/en/api/pipelines/flux).

---

# Limitations
- This model is not intended or able to provide factual information.
- As a statistical model this checkpoint might amplify existing societal biases.
- The model may fail to generate output that matches the prompts.
- Prompt following is heavily influenced by the prompting-style.

# Out-of-Scope Use
The model and its derivatives may not be used

- In any way that violates any applicable national, federal, state, local or international law or regulation.
- For the purpose of exploiting, harming or attempting to exploit or harm minors in any way; including but not limited to the solicitation, creation, acquisition, or dissemination of child exploitative content.
- To generate or disseminate verifiably false information and/or content with the purpose of harming others.
- To generate or disseminate personal identifiable information that can be used to harm an individual.
- To harass, abuse, threaten, stalk, or bully individuals or groups of individuals.
- To create non-consensual nudity or illegal pornographic content.
- For fully automated decision making that adversely impacts an individual's legal rights or otherwise creates or modifies a binding, enforceable obligation.
- Generating or facilitating large-scale disinformation campaigns.

# License
This model falls under the [`FLUX.1 [dev]` Non-Commercial License](https://huggingface.co/black-forest-labs/FLUX.1-Depth-dev/blob/main/LICENSE.md).