befox/Wan2.2-Animate-14B-GGUF
---
base_model:
- Wan-AI/Wan2.2-Animate-14B
---
GGUF version of [Wan-AI/Wan2.2-Animate-14B](https://huggingface.co/Wan-AI/Wan2.2-Animate-14B)

The face adapter tensors are quantized to a precision slightly higher than [QuantStack's](https://huggingface.co/QuantStack/Wan2.2-Animate-14B-GGUF), lower than 
[Kijai's](https://huggingface.co/Kijai/WanVideo_comfy_GGUF/tree/main/Wan22Animate)

<video controls autoplay loop muted width="480">
  <source src="https://huggingface.co/befox/Wan2.2-Animate-14B-GGUF/resolve/main/Wan2.2-Animate-14B-GGUF.webm" type="video/webm">
  Your browser does not support the video tag.
</video>