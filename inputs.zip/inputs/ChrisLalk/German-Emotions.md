ChrisLalk/German-Emotions
---
license: apache-2.0
datasets: google-research-datasets/go_emotions
base_model: FacebookAI/xlm-roberta-base
language:
- de
metrics:
- f1_macro: 0.45
- accuracy: 0.41
- kappa: 0.42
pipeline_tag: text-classification
tags:
- medical
model_description: 'This model was fine-tuned on the German translation of the go_emotions
  dataset. It is designed to classify German text across 27 emotions (and a "neutral"
  category). The model is fine-tuned on the FacebookAI/xlm-roberta-base model.  It
  contains the following emotions: ''admiration'', ''amusement'', ''anger'', ''annoyance'',
  ''approval'', ''caring'', ''confusion'', ''curiosity'', ''desire'', ''disappointment'',
  ''disapproval'', ''disgust'', ''embarrassment'', ''excitement'', ''fear'', ''gratitude'',
  ''grief'', ''joy'', ''love'', ''nervousness'', ''optimism'', ''pride'', ''realization'',
  ''relief'', ''remorse'', ''sadness'', ''surprise'', ''neutral''. '
---
# Model Card for German-Emotions

# German-Emotions
This model is designed to infer 27 emotions and a *neutral* category from German text. It is a fine-tuned version of **FacebookAI/xlm-roberta-base**, trained on the **German translation** of the [GoEmotions dataset](https://huggingface.co/datasets/google-research-datasets/go_emotions). 

The original GoEmotions dataset contains 53.4k English Reddit comments labeled with one or more emotions. For this model, the data was translated into German and used to fine-tune the multilingual XLM-RoBERTa base model (270M parameters), which was pretrained on 2.5TB of CommonCrawl data across 100 languages, including German.

For additional information, please see the reference at the bottom of this page. 
### Supported Emotion Labels
*admiration*, *amusement*, *anger*, *annoyance*, *approval*, *caring*, *confusion*, *curiosity*, *desire*, *disappointment*, *disapproval*, *disgust*, *embarrassment*, *excitement*, *fear*, *gratitude*, *grief*, *joy*, *love*, *nervousness*, *optimism*, *pride*, *realization*, *relief*, *remorse*, *sadness*, *surprise*, *neutral*

## Model Details

- **Model type:** text-classification
- **Language(s) (NLP):** German
- **License:** apache-2.0
- **Finetuned from model:** FacebookAI/xlm-roberta-base
- **Hyperparameters:**
    - Epochs: 10
    - learning_rate: 3e-5
    - weight_decay: 0.01
- **Metrics:**
    - accuracy: 0.41
    - f1: 0.45
    - kappa: 0.42
---
## Classification Metrics

| Emotion                 | Sentiment   | F1   | Cohen’s Kappa |
|--------------------------|-------------|------|---------------|
| admiration              | positive    | 0.64 | 0.601        |
| amusement               | positive    | 0.78 | 0.767        |
| anger                   | negative    | 0.38 | 0.358        |
| annoyance               | negative    | 0.27 | 0.229        |
| approval                | positive    | 0.34 | 0.293        |
| caring                  | positive    | 0.38 | 0.365        |
| confusion               | negative    | 0.40 | 0.378        |
| curiosity               | positive    | 0.51 | 0.486        |
| desire                  | positive    | 0.39 | 0.387        |
| disappointment          | negative    | 0.19 | 0.170        |
| disapproval             | negative    | 0.32 | 0.286        |
| disgust                 | negative    | 0.41 | 0.395        |
| embarrassment           | negative    | 0.37 | 0.367        |
| excitement              | positive    | 0.35 | 0.339        |
| fear                    | negative    | 0.59 | 0.584        |
| gratitude               | positive    | 0.89 | 0.882        |
| grief                   | negative    | 0.31 | 0.307        |
| joy                     | positive    | 0.51 | 0.499        |
| love                    | positive    | 0.73 | 0.721        |
| nervousness             | negative    | 0.28 | 0.276        |
| optimism                | positive    | 0.53 | 0.512        |
| pride                   | positive    | 0.30 | 0.299        |
| realization             | positive    | 0.17 | 0.150        |
| relief                  | positive    | 0.27 | 0.266        |
| remorse                 | negative    | 0.55 | 0.545        |
| sadness                 | negative    | 0.50 | 0.488        |
| surprise                | neutral     | 0.53 | 0.514        |
| neutral                 | neutral     | 0.60 | 0.410        |


## How to Get Started with the Model

Use the code below to get started with the model.

```python
import pandas as pd
from transformers import pipeline

# Example texts
texts = [
    "Ich fühle mich heute exzellent! Ich freue mich schon auf die Zeit mit meinen Freunden.",
    "Ich bin heute total müde und hab auf gar nichts Lust.",
    "Boah, das ist mir so peinlich.",
    "Hahaha, das ist so lustig."
]

# Create DataFrame
df = pd.DataFrame({"text": texts})

# Set labels
emotion_labels = ['admiration', 'amusement', 'anger', 'annoyance', 'approval', 'caring',
                  'confusion', 'curiosity', 'desire', 'disappointment', 'disapproval', 'disgust',
                  'embarrassment', 'excitement', 'fear', 'gratitude', 'grief', 'joy', 'love',
                  'nervousness', 'optimism', 'pride', 'realization', 'relief', 'remorse',
                  'sadness', 'surprise', 'neutral']

# Load emotion classifier pipeline
emo_pipe = pipeline(
    "text-classification",
    model="ChrisLalk/German-Emotions",  # or local model path
    tokenizer="ChrisLalk/German-Emotions",
    return_all_scores=True,
    truncation=True,
    top_k=None
)

# Infer the probability scores
prob_results = []
for text in df["text"]:
    scores = emo_pipe(text)[0]
    result_dict = {item["label"]: item["score"] for item in scores}
    result_dict_sort = {label: result_dict[label] for label in emotion_labels}
    prob_results.append(result_dict_sort)

# Add emotion scores to DataFrame
df_probs = pd.DataFrame(prob_results, columns=emotion_labels)
df_final = pd.concat([df, df_probs], axis=1)
```

### Citation: 
When using our model, please cite the associated peer-reviewed paper:
<pre> bibtex @article{Lalk2025EmotionDetection, 
  author = {Christopher Lalk and Kim Targan and Tobias Steinbrenner and Jana Schaffrath and Steffen Eberhardt and Brian Schwartz and Antonia Vehlen and Wolfgang Lutz and Julian Rubel}, 
  title = {Employing large language models for emotion detection in psychotherapy transcripts}, 
  journal = {Frontiers in Psychiatry}, 
  volume = {16}, 
  year = {2025}, 
  doi = {10.3389/fpsyt.2025.1504306}} </pre>