calcuis/hunyuanimage-gguf
---
license: other
license_name: tencent-hunyuan-community
license_link: https://github.com/Tencent-Hunyuan/HunyuanImage-2.1/blob/main/LICENSE
base_model:
- tencent/HunyuanImage-2.1
pipeline_tag: text-to-image
tags:
- gguf-node
widget:
- text: cute anime girl with massive fennec ears and a big fluffy fox tail with long
    wavy blonde hair between eyes and large blue eyes blonde colored eyelashes chubby
    wearing oversized clothes summer uniform large black coat long blue maxi skirt
    muddy clothes happy sitting on the side of the road in a run down dark gritty
    cyberpunk city with neon and a crumbling skyscraper in the rain at night while
    dipping her feet in a river of water she is holding a sign that says "ComfyUI
    is the best" and another one that says "The Future is PIG"
  parameters:
    negative_prompt: low quality, bad anatomy, extra digits, missing digits, extra
      limbs, missing limbs
  output:
    url: workflow-demo1.png
- text: cute anime girl with massive fennec ears and a big fluffy fox tail with long
    wavy blonde hair between eyes and large blue eyes blonde colored eyelashes chubby
    wearing oversized clothes summer uniform large black coat long blue maxi skirt
    muddy clothes happy sitting on the side of the road in a run down dark gritty
    cyberpunk city with neon and a crumbling skyscraper in the rain at night while
    dipping her feet in a river of water she is holding a sign that says "PIG is the
    best" and another one that says "The Future is gguf"
  parameters:
    negative_prompt: low quality, bad anatomy, extra digits, missing digits, extra
      limbs, missing limbs
  output:
    url: workflow-demo2.png
- text: cute anime girl with massive fennec ears and a big fluffy fox tail with long
    wavy blonde hair between eyes and large blue eyes blonde colored eyelashes chubby
    wearing oversized clothes summer uniform large black coat long blue maxi skirt
    muddy clothes happy sitting on the side of the road in a run down dark gritty
    cyberpunk city with neon and a crumbling skyscraper in the rain at night while
    dipping her feet in a river of water she is holding a sign that says "Comfy is
    the best" and another one that says "The Future is PIG"
  parameters:
    negative_prompt: low quality, bad anatomy, extra digits, missing digits, extra
      limbs, missing limbs
  output:
    url: workflow-demo3.png
---
## hunyuanimage-gguf
- drag **hunyuanimage2.1** (opt anyone you like) to > `./ComfyUI/models/diffusion_models`
- drag **byt5-sm** [[127MB](https://huggingface.co/calcuis/pig-encoder/blob/main/byt5_small_glyphxl_fp32-iq4_nl.gguf)] and **qwen2.5-vl-7b** [[5.03GB](https://huggingface.co/calcuis/hunyuanimage-gguf/blob/main/qwen2.5-vl-7b-test-q4_0.gguf)] to > `./ComfyUI/models/text_encoders`
- drag **pig** [[811MB](https://huggingface.co/calcuis/pig-vae/blob/main/pig_hunyuan_image_vae_fp32-f16.gguf)] to > `./ComfyUI/models/vae`

![screenshot](https://raw.githubusercontent.com/calcuis/comfy/master/hyimg.png)

<Gallery />

![screenshot](https://raw.githubusercontent.com/calcuis/comfy/master/hyimg1.png)

for standard model, all files should work - running them with gguf node via comfyui; and v2 is more lightweighted; both of them should be able to generate quality output with 12-15 steps

![screenshot](https://raw.githubusercontent.com/calcuis/comfy/master/hyimg2.png)

note: for refiner model, please use **v2**; initial test for refining blur image (runnable test only); could load any picture, i.e., output from q2, blur, distorted, poor in quality, etc., to refine/sharpen it

![screenshot](https://raw.githubusercontent.com/calcuis/comfy/master/hyimg3.png)

note: for distilled model, please use **v2**; able to generate output with merely 8 steps (see picture)

![screenshot](https://raw.githubusercontent.com/calcuis/comfy/master/hyimg-lite.png)

for lite model, run it with 8 steps + 1 cfg; output is identical to standard model; but 2-3x faster

![screenshot](https://raw.githubusercontent.com/calcuis/comfy/master/hyimg-lite2.2xxs.png)

the new lite v2.2, output should be 80-90% closed to the standard model; save up to 60-70% loading time, depends on how you config the steps and cfg (demo above: steps=10; cfg=1.5)

- get scaled fp8 safetensors encoder [here](https://huggingface.co/chatpig/encoder/blob/main/qwen_2.5_vl_7b_fp8_e4m3fn.safetensors) if your gpu doesn't release vram after several running attempts; it might vary among different cards/drivers, do your own research always

### **reference**
- gguf-node ([pypi](https://pypi.org/project/gguf-node)|[repo](https://github.com/calcuis/gguf)|[pack](https://github.com/calcuis/gguf/releases))