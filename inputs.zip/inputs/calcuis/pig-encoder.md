calcuis/pig-encoder
---
license: mit
language:
- en
tags:
- pig
- gguf-node
widget:
- text: a pinky pig moving quickly in a beautiful winter scenery nature trees sunset
    tracking camera
  output:
    url: samples\ComfyUI_00001_.webp
- text: close-up portrait of anime pig
  output:
    url: samples\ComfyUI_00001_.png
- text: close-up portrait of anime pig
  output:
    url: samples\ComfyUI_00002_.png
- text: close-up portrait of pig
  output:
    url: samples\ComfyUI_00003_.png
---

# 🐷pig architecture gguf encoder
[<img src="https://raw.githubusercontent.com/calcuis/comfy/master/pig.gif" width="128" height="128">](https://github.com/calcuis/gguf)
- text encoder base model from [google](https://huggingface.co/google)
- llama encoder base model from [meta](https://huggingface.co/meta-llama)
- pig architecture from [connector](https://huggingface.co/connector)
- 50% faster at least; compare to safetensors version
- save memory up to 50% as well; good for old machine
- compatible with all model; no matter safetensors or gguf
- tested on pig-1k/1k-aura/1k-turbo/cosmos, etc.; works fine
- upgrade your node for **pig**🐷 encoder support
- you could drag the picture below to your browser for example workflow

<Gallery />