calcuis/hidream-gguf
---
license: mit
language:
- en
base_model:
- HiDream-ai/HiDream-I1-Full
pipeline_tag: text-to-image
tags:
- gguf-node
widget:
- text: cute anime girl with massive fluffy fennec ears and a big fluffy tail blonde
    messy long hair blue eyes wearing a maid outfit with a long black gold leaf pattern
    dress and a white apron mouth open holding a fancy black forest cake with candles
    on top in the kitchen of an old dark Victorian mansion lit by candlelight with
    a bright window to the foggy forest and very expensive stuff everywhere
  parameters:
    negative_prompt: full (info only, don't copy this)
  output:
    url: samples\ComfyUI_00004_.png
- text: fast (same prompt as full)
  output:
    url: samples\ComfyUI_00005_.png
- text: dev (same prompt as full)
  output:
    url: samples\ComfyUI_00006_.png
- text: 1-clip (llama only)
  output:
    url: samples\ComfyUI_00001_.png
- text: 2-clip (llama + t5xxl)
  output:
    url: samples\ComfyUI_00002_.png
---

## gguf quantized version of HiDream-i1-Full (incl. full + dev + fast + e1 + e1-1)
- full set gguf works right away (all gguf: model + encoder + vae)
- upgrade your node([pypi](https://pypi.org/project/gguf-node)|[repo](https://github.com/calcuis/gguf)|[pack](https://github.com/calcuis/gguf/releases)) for model support

![screenshot](https://raw.githubusercontent.com/calcuis/comfy/master/hidream.png)

### setup
- drag **hidream** to > `./ComfyUI/models/diffusion_models`
- drag **encoder**: g, l, t5xxl and llama to > `./ComfyUI/models/text_encoders`
- drag **pig** to > `./ComfyUI/models/vae`

### workflow
- drag the [json](https://huggingface.co/calcuis/hidream-gguf/blob/main/workflow-hidream.json) file or demo picture below for example workflow

<Gallery />

### reference
- base model from [hidream-ai](https://huggingface.co/HiDream-ai)
- get safetensors from [comfy-org](https://huggingface.co/Comfy-Org/HiDream-I1_ComfyUI/tree/main/split_files)
- get more t5xxl-encoder gguf [here](https://huggingface.co/chatpig/t5-v1_1-xxl-encoder-fp32-gguf/tree/main)
- get more lama3.1-8b-encoder gguf [here](https://huggingface.co/chatpig/llama-3.1-8b-encoder-gguf/tree/main)