calcuis/wan2-gguf
---
license: apache-2.0
pipeline_tag: text-to-video
tags:
- gguf-node
base_model:
- Comfy-Org/Wan_2.2_ComfyUI_Repackaged
widget:
- text: a cute anime girl picking up a little pinky pig and moving quickly
  parameters:
    negative_prompt: blurry ugly bad
  output:
    url: workflow-14b-i2v.webp
- text: drone shot of a volcano erupting with a pig walking on it
  parameters:
    negative_prompt: blurry ugly bad
  output:
    url: workflow-embedded.webm
- text: drone shot of a volcano erupting with a pig walking on it
  parameters:
    negative_prompt: blurry ugly bad
  output:
    url: workflow-embedded.webp
---
## **gguf quantized version of wan2.2 models**
- drag **wan** to > `./ComfyUI/models/diffusion_models`
- drag **umt5xxl** to > `./ComfyUI/models/text_encoders`
- drag **pig** to > `./ComfyUI/models/vae`

<Gallery />

![screenshot](https://raw.githubusercontent.com/calcuis/comfy/master/wan-animate.png)
tip: the lite lora for **s2v** [[1.23GB](https://huggingface.co/calcuis/wan2-gguf/blob/main/wan2.2_s2v_lite_lora.safetensors)], can apply to **animate** model also

![screenshot](https://raw.githubusercontent.com/calcuis/comfy/master/wan22-gguf.png)
tip: for **5b** model, use **pig-wan2-vae** [[1.41GB](https://huggingface.co/calcuis/wan2-gguf/blob/main/pig_wan2_vae_fp32-f16.gguf)]; for **14b** model, please use **pig-wan-vae** [[254MB](https://huggingface.co/calcuis/wan2-gguf/blob/main/pig_wan_vae_fp32-f16.gguf)]

![screenshot](https://raw.githubusercontent.com/calcuis/comfy/master/wan-s2v.png)
for **s2v** model setup, please refer to [here](https://huggingface.co/calcuis/wan-s2v-gguf)

### **update**
- upgrade your node (see last item from reference) for new/full quant support
- get more **umt5xxl** gguf encoder either [here](https://huggingface.co/calcuis/pig-encoder/tree/main) or [here](https://huggingface.co/chatpig/umt5xxl-encoder-gguf/tree/main)

### **reference**
- base model from [wan-ai](https://huggingface.co/Wan-AI)
- 4/8-step lightning lora from [lightx2v](https://huggingface.co/lightx2v/Wan2.2-Lightning)
- comfyui from [comfyanonymous](https://github.com/comfyanonymous/ComfyUI)
- gguf-node ([pypi](https://pypi.org/project/gguf-node)|[repo](https://github.com/calcuis/gguf)|[pack](https://github.com/calcuis/gguf/releases))