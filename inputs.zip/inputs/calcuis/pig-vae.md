calcuis/pig-vae
---
license: mit
language:
- en
tags:
- pig
- gguf-node
widget:
- text: a pig moving quickly in a beautiful winter scenery nature trees sunset tracking
    camera
  output:
    url: samples\ComfyUI_00001_.webp
- text: a pinky pig swimming in a beautiful lake scenery nature rock and hill sunset
    tracking camera
  output:
    url: samples\ComfyUI_00003_.webp
- text: a pinky pig moving quickly in a beautiful winter scenery nature trees sunset
    tracking camera
  parameters:
    negative_prompt: blurry ugly bad
  output:
    url: samples\ComfyUI_00002_.webp
- text: close-up portrait of girl
  output:
    url: samples\ComfyUI_00006_.png
- text: close-up portrait of cat
  output:
    url: samples\ComfyUI_00005_.png
- text: close-up portrait of pig
  output:
    url: samples\ComfyUI_00002_.png
---

# 🐷pig architecture gguf vae
[<img src="https://raw.githubusercontent.com/calcuis/comfy/master/pig.gif" width="128" height="128">](https://github.com/calcuis/gguf)
- pig architecture from [connector](https://huggingface.co/connector)
- 25-50% faster; compare to safetensors version
- save memory up to 25-50%; good for old machine
- compatible with all model; no matter safetensors or gguf
- upgrade your node ([pypi](https://pypi.org/project/gguf-node)|[repo](https://github.com/calcuis/gguf)) for **pig**🐷 vae support; with the new **gguf vae loader**
- you could drag the picture/video below to your browser for example workflow
- tips: make good use of the **convertor zero** for gguf model/encoder/vae🐷 conversion

<Gallery />