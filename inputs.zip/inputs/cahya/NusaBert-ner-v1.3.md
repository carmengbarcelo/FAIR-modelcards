cahya/NusaBert-ner-v1.3
---
library_name: transformers
base_model: cahya/NusaBert-v1.3
tags:
- generated_from_trainer
datasets:
- grit-id/id_nergrit_corpus
metrics:
- precision
- recall
- f1
- accuracy
pipeline_tag: token-classification
license: mit
language:
- id
model-index:
- name: nusabert_nergrit_1.3
  results:
  - task:
      type: token-classification
      name: Token Classification
    dataset:
      name: grit-id/id_nergrit_corpus ner
      type: grit-id/id_nergrit_corpus
      config: ner
      split: validation
      args: ner
    metrics:
    - type: precision
      value: 0.8010483135824977
      name: Precision
    - type: recall
      value: 0.8338275412169375
      name: Recall
    - type: f1
      value: 0.8171093159760562
      name: F1
    - type: accuracy
      value: 0.9476653696498054
      name: Accuracy
---

<!-- This model card has been generated automatically according to the information the Trainer had access to. You
should probably proofread and complete it, then remove this comment. -->

# NusaBert-ner-v1.3

This model is a fine-tuned version of [cahya/NusaBert-v1.3](https://huggingface.co/cahya/NusaBert-v1.3) on the grit-id/id_nergrit_corpus ner dataset.
It supports a context length of 8192, the same as the model *cahya/NusaBert-v1.3* which was pre-trained from scratch using ModernBERT architecture.
It achieves the following results on the evaluation set:
- Loss: 0.2174
- Precision: 0.8010
- Recall: 0.8338
- F1: 0.8171
- Accuracy: 0.9477

## Model description

The dataset contains 19 following entities
```
    'CRD': Cardinal
    'DAT': Date
    'EVT': Event
    'FAC': Facility
    'GPE': Geopolitical Entity
    'LAW': Law Entity (such as Undang-Undang)
    'LOC': Location
    'MON': Money
    'NOR': Political Organization
    'ORD': Ordinal
    'ORG': Organization
    'PER': Person
    'PRC': Percent
    'PRD': Product
    'QTY': Quantity
    'REG': Religion
    'TIM': Time
    'WOA': Work of Art
    'LAN': Language
```

## Intended uses & limitations

More information needed

## Training and evaluation data

More information needed

## Training procedure

### Training hyperparameters

The following hyperparameters were used during training:
- learning_rate: 5e-05
- train_batch_size: 32
- eval_batch_size: 32
- seed: 42
- distributed_type: multi-GPU
- num_devices: 2
- total_train_batch_size: 64
- total_eval_batch_size: 64
- optimizer: Use adamw_torch with betas=(0.9,0.999) and epsilon=1e-08 and optimizer_args=No additional optimizer arguments
- lr_scheduler_type: linear
- num_epochs: 3.0

### Training results



### Framework versions

- Transformers 4.49.0
- Pytorch 2.5.1+cu124
- Datasets 2.19.2
- Tokenizers 0.21.0

## Usage
```
from transformers import pipeline
ner = pipeline("ner", model="cahya/NusaBert-ner-v1.3", grouped_entities=True)
text = "Jakarta, April 2025 - Polisi mengungkap sosok teman pemberi uang palsu kepada artis Sekar Arum Widara. Sosok tersebut ternyata adalah Bayu Setio Aribowo (BS), pegawai nonaktif Garuda yang ditangkap Polsek Tanah Abang di kasus serupa."
result = ner(text)
print(result)
```