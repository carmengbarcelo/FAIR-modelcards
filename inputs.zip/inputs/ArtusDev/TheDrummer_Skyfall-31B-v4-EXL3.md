ArtusDev/TheDrummer_Skyfall-31B-v4-EXL3
---
base_model: TheDrummer/Skyfall-31B-v4
base_model_relation: quantized
quantized_by: ArtusDev
tags:
- exl3
---

## EXL3 Quants of TheDrummer/Skyfall-31B-v4

EXL3 quants of [TheDrummer/Skyfall-31B-v4](https://huggingface.co/TheDrummer/Skyfall-31B-v4) using <a href="https://github.com/turboderp-org/exllamav3/">exllamav3</a> for quantization.

### Quants
| Quant(Revision) | Bits per Weight | Head Bits |
| -------- | ---------- | --------- |
| [2.5_H6](https://huggingface.co/ArtusDev/TheDrummer_Skyfall-31B-v4-EXL3/tree/2.5bpw_H6) | 2.5 | 6 |
| [3.0_H6](https://huggingface.co/ArtusDev/TheDrummer_Skyfall-31B-v4-EXL3/tree/3.0bpw_H6) | 3.0 | 6 |
| [3.5_H6](https://huggingface.co/ArtusDev/TheDrummer_Skyfall-31B-v4-EXL3/tree/3.5bpw_H6) | 3.5 | 6 |
| [4.0_H6](https://huggingface.co/ArtusDev/TheDrummer_Skyfall-31B-v4-EXL3/tree/4.0bpw_H6) | 4.0 | 6 |
| [4.25_H6](https://huggingface.co/ArtusDev/TheDrummer_Skyfall-31B-v4-EXL3/tree/4.25bpw_H6) | 4.25 | 6 |
| [4.5_H6](https://huggingface.co/ArtusDev/TheDrummer_Skyfall-31B-v4-EXL3/tree/4.5bpw_H6) | 4.5 | 6 |
| [5.0_H6](https://huggingface.co/ArtusDev/TheDrummer_Skyfall-31B-v4-EXL3/tree/5.0bpw_H6) | 5.0 | 6 |
| [6.0_H6](https://huggingface.co/ArtusDev/TheDrummer_Skyfall-31B-v4-EXL3/tree/6.0bpw_H6) | 6.0 | 6 |
| [8.0_H8](https://huggingface.co/ArtusDev/TheDrummer_Skyfall-31B-v4-EXL3/tree/8.0bpw_H8) | 8.0 | 8 |

### Downloading quants with huggingface-cli

<details>
  <summary>Click to view download instructions</summary>

Install hugginface-cli:

```bash
pip install -U "huggingface_hub[cli]"
```

Download quant by targeting the specific quant revision (branch):

```
huggingface-cli download ArtusDev/TheDrummer_Skyfall-31B-v4-EXL3 --revision "5.0bpw_H6" --local-dir ./
```
</details>