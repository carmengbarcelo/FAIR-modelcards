adept/persimmon-8b-chat
---
license: apache-2.0
---

At Adept, we’re working towards an AI agent that can help people do anything they need to do on a computer. We’re not in the business of shipping isolated language models (LMs)—this was an early output of the model scaling program that will support our products.

We trained it from scratch using a context size of 16K. Many LM use cases are context-bound; our model has 4 times the context size of LLaMA2 and 8 times that of GPT-3, MPT, etc.

This is a chat finetuned version of the base model.  The best prompt to use is:

human: [some query]

adept:



See https://www.adept.ai/blog/persimmon-8b for more info