bardsai/twitter-emotion-pl-base
---
language: pl
tags:
- text-classification
- twitter
datasets:
- datasets/tweet_eval
metrics:
- f1
- accuracy
- precision
- recall
widget:
- text: Nigdy przegrana nie sprawiła mi takiej radości. Szczęście i Opatrzność mają
    znaczenie Gratuluje @pzpn_pl
  example_title: Example 1
- text: Osoby z Ukrainy zapłacą za życie w centrach pomocy? Sprzeczne prawem UE, niehumanitarne,
    okrutne.
  example_title: Example 2
---


# Twitter emotion PL (base)

Twitter emotion PL (base) is a model based on [herbert-base](https://huggingface.co/allegro/herbert-base-cased) for analyzing emotion of Polish twitter posts. It was trained on the translated version of [TweetEval](https://www.researchgate.net/publication/347233661_TweetEval_Unified_Benchmark_and_Comparative_Evaluation_for_Tweet_Classification) by Barbieri et al., 2020 for 10 epochs on single RTX3090 gpu.

The model will give you a four labels: joy, optimism, sadness and anger.

## How to use

You can use this model directly with a pipeline for text classification:

```python
from transformers import pipeline

nlp = pipeline("text-classification", model="bardsai/twitter-emotion-pl-base")
nlp("Nigdy przegrana nie sprawiła mi takiej radości. Szczęście i Opatrzność mają znaczenie Gratuluje @pzpn_pl")
```
```bash
[{'label': 'joy', 'score': 0.5163766145706177}]
```

## Performance
| Metric | Value |
| --- | ----------- |
| f1 macro | 0.756 |
| precision macro | 0.767 |
| recall macro | 0.750 |
| accuracy | 0.789 |
| samples per second | 131.6 |

(The performance was evaluated on RTX 3090 gpu)

## Changelog
- 2023-07-19: Initial release

## About bards.ai

At bards.ai, we focus on providing machine learning expertise and skills to our partners, particularly in the areas of nlp, machine vision and time series analysis. Our team is located in Wroclaw, Poland. Please visit our website for more information: [bards.ai](https://bards.ai/)

Let us know if you use our model :). Also, if you need any help, feel free to contact us at info@bards.ai