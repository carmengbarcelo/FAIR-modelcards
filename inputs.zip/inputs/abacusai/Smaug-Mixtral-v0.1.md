abacusai/Smaug-Mixtral-v0.1
---
license: apache-2.0
tags:
- mixtral
- finetune
---

## Overview

This model is part of the Smaug series of finetuned models. This one based on https://huggingface.co/mistralai/Mixtral-8x7B-v0.1

We use a new fine-tuning technique, DPO-Positive (DPOP), and new pairwise preference versions of ARC, HellaSwag, and MetaMath (as well as other existing datasets). 
We introduce the technique and the full training details in our new paper: https://arxiv.org/abs/2402.13228.

We show that on datasets in which the edit distance between pairs of completions is low (such as in math-based datasets), standard DPO loss can lead to a reduction of the model's likelihood of the preferred examples, as long as the relative probability between the preferred and dispreferred classes increases. 
Using these insights, we design DPOP, a new loss function and training procedure which avoids this failure mode. 
Surprisingly, we also find that DPOP outperforms DPO across a wide variety of datasets and downstream tasks, including datasets with high edit distances between completions.

We believe this new approach is generally useful in training across a wide range of model types and downstream use cases, and it powers all of our Smaug models. 
With the release of our paper and datasets, we are excited for the open source community to continue to build on and improve Smaug and spawn more dragons to dominate the LLM space!

Keep watching this space for our announcements!

### Evaluation Results

| Average | ARC | HellaSwag | MMLU | TruthfulQA | Winogrande | GSM8K |
| --- | --- | --- | --- | --- | --- | --- |
|  75.12  | 74.91 | 87.70  | 70.16 | 65.96 | 81.61 | 70.36 |