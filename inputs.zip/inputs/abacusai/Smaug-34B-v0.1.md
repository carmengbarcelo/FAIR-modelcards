abacusai/Smaug-34B-v0.1
---
base_model: jondurbin/bagel-34b-v0.2
license: apache-2.0
---

![image/png](https://cdn-uploads.huggingface.co/production/uploads/64c14f6b02e1f8f67c73bd05/pf4d6FA7DriRtVq5HCkxd.png)


![image/png](https://cdn-uploads.huggingface.co/production/uploads/64c14f6b02e1f8f67c73bd05/e4u8VYfDBh11u60rFYJHF.png)

This model is a finetune of jondurbin's excellent [bagel](https://huggingface.co/jondurbin/bagel-34b-v0.2) model. This model has not utilised any form of merging.

We created Smaug-34B-v0.1 using a new fine-tuning technique, DPO-Positive (DPOP), and new pairwise preference versions of ARC, HellaSwag, and MetaMath (as well as other existing datasets). 
We introduce the technique and the full training details in our new paper: https://arxiv.org/abs/2402.13228.

We show that on datasets in which the edit distance between pairs of completions is low (such as in math-based datasets), standard DPO loss can lead to a reduction of the model's 
likelihood of the preferred examples, as long as the relative probability between the preferred and dispreferred classes increases. 
Using these insights, we design DPOP, a new loss function and training procedure which avoids this failure mode. 
Surprisingly, we also find that DPOP outperforms DPO across a wide variety of datasets and downstream tasks, including datasets with high edit distances between completions.

We believe this new approach is generally useful in training across a wide range of model types and downstream use cases, and it powers all of our Smaug models.
With the release of our paper and datasets, we are excited for the open source community to continue to build on and improve Smaug and spawn more dragons to dominate the LLM space!


### Evaluation Results

| Average | ARC | HellaSwag | MMLU | TruthfulQA | Winogrande | GSM8K |
| --- | --- | --- | --- | --- | --- | --- |
|  77.29  | 74.23 | 86.76  | 76.66 | 70.22 | 83.66 | 72.18 |

### Contamination Results

With reference model jondurbin/bagel-34b-v0.2:

| ARC | TruthfulQA | GSM8K |
| --- | --- | --- |
| 0.08| 0.38| 0.88|

### Citation

Please cite the paper if you use data, model, or method in this repo.

```
@article{pal2024smaug,
  title={Smaug: Fixing Failure Modes of Preference Optimisation with DPO-Positive},
  author={Pal, Arka and Karkhanis, Deep and Dooley, Samuel and Roberts, Manley and Naidu, Siddartha and White, Colin},
  journal={arXiv preprint arXiv:2402.13228},
  year={2024}
}
```